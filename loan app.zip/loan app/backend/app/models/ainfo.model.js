module.exports = (mongoose) => {
  var schema = mongoose.Schema(
    {
      firm: String,
      aname: String,
      aemail: String,
      anumber: String,
    },
    { timestamps: true }
  );
  schema.method("toJSON", function () {
    const { __v, _id, ...object } = this.toObject();
    object.id = _id;
    return object;
  });
  const ainfo = mongoose.model("ainfo", schema);
  return ainfo;
};
