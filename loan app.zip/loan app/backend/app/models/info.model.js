module.exports = (mongoose) => {
  var schema = mongoose.Schema(
    {
      fname: String,
      lname: String,
      email: String,
      region: String,
      id: String,
    },
    { timestamps: true }
  );
  schema.method("toJSON", function () {
    const { __v, _id, ...object } = this.toObject();
    object.id = _id;
    return object;
  });
  const info = mongoose.model("info", schema);
  return info;
};
