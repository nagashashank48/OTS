module.exports = (app) => {
  const loan = require("../controllers/loan.controller.js");
  var router = require("express").Router();
  router.get("/", loan.findAll);
  router.put("/:id", loan.update);
  router.delete("/:id", loan.delete);
  app.use("/api/loans", router);
};
