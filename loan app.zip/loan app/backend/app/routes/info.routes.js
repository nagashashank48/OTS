module.exports = (app) => {
  const info = require("../controllers/info.controller.js");
  var router = require("express").Router();
  // Create a new user
  router.post("/", info.create);
  router.get("/", info.findAll);
  router.put("/:id", info.update);

  app.use("/api/infos", router);
};
