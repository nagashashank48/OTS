const db = require("../models");
const Ainfo = db.ainfos;
// Create and Save a new user
exports.create = (req, res) => {
  if (!req.body.aemail) {
    res.status(400).send({ message: "Content can not be empty!" });
    return;
  }
  // Create a user
  const ainfo = new Ainfo({
    firm: req.body.firm,
    aname: req.body.aname,
    aemail: req.body.aemail,
    anumber: req.body.anumber,
  });
  // Save user in the database
  ainfo
    .save(ainfo)
    .then((data) => {
      res.send(data);
    })
    .catch((err) => {
      res.status(500).send({
        message: err.message || "Some error occurred while creating the user.",
      });
    });
};

exports.findAll = async (req, res) => {
  await Ainfo.find()
    .then((data) => {
      res.send(data);
    })
    .catch((err) => {
      res.status(500).send({
        message: err.message || "Some error occurred while retrieving report.",
      });
    });
};
exports.update = (req, res) => {
  if (!req.body) {
    return res.status(400).send({
      message: "Data to update can not be empty!",
    });
  }
  const id = req.params.id;
  Ainfo.findByIdAndUpdate(id, req.body, { useFindAndModify: false })
    .then((data) => {
      if (!data) {
        res.status(404).send({
          message: `Cannot update screen with id=${id}. Maybe screen  was not found!`,
        });
      } else res.send({ message: "Screen  was updated successfully." });
    })
    .catch((err) => {
      res.status(500).send({
        message: "Error updating screen  with id=" + id,
      });
    });
};
