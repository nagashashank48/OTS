import { render, screen, cleanup, waitFor } from "@testing-library/react";

import "@testing-library/jest-dom";
import Myprofile from "./pages/Myprofile";
import AxiosMock from "axios";
import { BrowserRouter } from "react-router-dom";

afterEach(() => {
  cleanup();
});
it("async axios request", async () => {
  AxiosMock.get.mockResolvedValue({ data: { region: "hyderabad" } });
  const url = "http://localhost:8080/api/infos";

  const { getByTestId, getByText } = render(
    <BrowserRouter>
      <Myprofile url={url} />
    </BrowserRouter>
  );
  expect(getByText(/Region/).textContent).toBe("Region");

  const resolveElement = await waitFor(() => getByTestId("button"));
  expect(resolveElement.textContent).toBe("Edit");
  expect(AxiosMock.get).toHaveBeenCalledTimes(1);
  expect(AxiosMock.get).toHaveBeenCalledWith(url);
});
