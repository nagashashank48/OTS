import React, { useState, useEffect } from "react";
import Sidebar from "../components/sidebar";
import { Row, Col, Button } from "react-bootstrap";
import axios from "axios";
import { NavLink } from "react-router-dom";

import { toast } from "react-toastify";

import "react-toastify/dist/ReactToastify.css";
toast.configure();
const Accountinfo = () => {
  const [formInputs, setformInputs] = useState({
    firm: "",
    aname: "",
    aemail: "",
    anumber: "",
  });
  const [errors, setErrors] = useState({});
  useEffect(() => {
    axios
      .get("http://localhost:8080/api/ainfos")
      .then((response) => {
        const ord = [...response.data];
        setformInputs({
          firm: ord[0].firm,
          aname: ord[0].aname,
          email: ord[0].aemail,
          anumber: ord[0].anumber,
          id: ord[0].id,
        });
      })
      .catch((error) => {
        console.log(error);
      });
  }, []);

  const onValueChange = (e) => {
    const name = e.target.name;
    const value = e.target.value;
    setformInputs((values) => ({ ...values, [name]: value }));
  };
  const handleClick = () => {
    if (validate()) {
      axios
        .put(`http://localhost:8080/api/ainfos/${formInputs.id}`, formInputs)

        .then((res) => {
          console.log(formInputs);
          toast.success("Details Saved Successfully ", {
            position: toast.POSITION.BOTTOM_LEFT,
            autoClose: 3000,
          });
        });
    }
  };
  const validate = () => {
    let isValid = true;
    let error = {};

    if (!formInputs["firm"]) {
      isValid = false;
      error["firm"] = "Please enter the  accouting's firm.";
    }
    if (!formInputs["aname"]) {
      isValid = false;
      error["aname"] = "Please enter your acountant's  name.";
    }
    if (typeof formInputs["anumber"] !== "undefined") {
      var pattern = new RegExp(/^[0-9\b]+$/);
      if (!pattern.test(formInputs["anumber"])) {
        isValid = false;
        error["anumber"] = "Please enter only number.";
      } else if (formInputs["anumber"].length !== 10) {
        isValid = false;
        error["anumber"] = "Please enter valid Telephone number.";
      }
    }

    if (typeof formInputs["aemail"] !== "undefined") {
      var pattern2 = new RegExp(
        /^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i
      );
      if (!pattern2.test(formInputs["aemail"])) {
        isValid = false;
        error["aemail"] = "Please enter valid email address.";
      }
    }

    setErrors(error);

    return isValid;
  };
  return (
    <div className="total">
      <Row>
        <Col sm="3" className="sidebar">
          <Sidebar />
        </Col>
        <Col
          style={{
            paddingRight: "50px",
            paddingLeft: "50px",
            paddingTop: "40px",
          }}
        >
          <div className="header">Accountant Information</div>
          <div>Accounting Firm</div>
          <input
            type="text"
            className="form-control"
            name="firm"
            value={formInputs.firm}
            placeholder="Enter Your First Name"
            onChange={(e) => onValueChange(e)}
            required
          ></input>
          {errors.firm ? <div className="errors">{errors.firm}</div> : null}
          <br></br>
          <div>Accountant's Name</div>
          <input
            type="text"
            className="form-control"
            name="aname"
            value={formInputs.aname}
            placeholder="Enter Your Last Name"
            onChange={(e) => onValueChange(e)}
            required
          ></input>
          {errors.aname ? <div className="errors">{errors.aname}</div> : null}
          <br></br>
          <div>Accountant's Telephone Number</div>
          <input
            type="text"
            className="form-control"
            name="anumber"
            value={formInputs.anumber}
            placeholder="Enter Your Telephone Number"
            onChange={(e) => onValueChange(e)}
            required
          ></input>
          {errors.anumber ? (
            <div className="errors">{errors.anumber}</div>
          ) : null}
          <br></br>
          <div>Accountant's Email Adress</div>
          <input
            type="text"
            className="form-control"
            name="aemail"
            value={formInputs.email}
            placeholder="Enter Your Region "
            onChange={(e) => onValueChange(e)}
            required
          ></input>
          {errors.aemail ? <div className="errors">{errors.aemail}</div> : null}
          <br></br>
          <Button variant="light" style={{ float: "right" }}>
            Cancel
          </Button>
          <NavLink to="/myprofile">
            <Button variant="primary" style={{ float: "right" }}>
              Previous
            </Button>
          </NavLink>
          <Button
            variant="primary"
            style={{ float: "right" }}
            onClick={handleClick}
          >
            Edit
          </Button>
        </Col>
      </Row>
    </div>
  );
};

export default Accountinfo;
