import React, { useState, useEffect } from "react";
import { styled } from "@mui/material/styles";
import Container from "@mui/material/Container";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell, { tableCellClasses } from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Axios from "axios";
import Sidebar from "../components/sidebar";
import { Row, Col, Form, Modal, Button } from "react-bootstrap";
import { toast } from "react-toastify";

import "react-toastify/dist/ReactToastify.css";
toast.configure();

const StyledTableCell = styled(TableCell)(({ theme }) => ({
  [`&.${tableCellClasses.head}`]: {
    backgroundColor: "white",
    color: theme.palette.common.black,
    fontSize: "16px",
    fontWeight: "bold",
  },
  [`&.${tableCellClasses.body}`]: {
    fontSize: 16,
  },
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
  "&:nth-of-type(odd)": {
    backgroundColor: theme.palette.action.hover,
  },
  "&:last-child td, &:last-child th": {
    border: 0,
  },
}));

export default function TableDataStudent() {
  const [users, setUsers] = useState([]);

  const [show, setShow] = useState(false);
  const [formInputs, setformInputs] = useState({
    reason: "",
    id: "",
    status: "",
  });
  const [deletemodal, setDeleteModal] = useState({
    id: "",
    reason: "",
    show: false,
  });
  const [info, setInfo] = useState({});

  const handleClose = () => setShow(false);
  useEffect(() => {
    Axios.get("http://localhost:8080/api/loans")
      .then((response) => {
        const ord = [...response.data];
        setUsers(ord);
      })
      .catch((error) => {
        console.log(error);
      });

    Axios.get("http://localhost:8080/api/infos")
      .then((response) => {
        const ord = [...response.data];
        setInfo({ fname: ord[0].fname, lname: ord[0].lname });
      })
      .catch((error) => {
        console.log(error);
      });
  }, []);

  const deleteOrder = (id, reason) => {
    setDeleteModal({ id: id, reason: reason, show: !deletemodal.show });
  };
  const handleDelete = (id, name) => {
    Axios.delete(`http://localhost:8080/api/loans/${id}`).then((res) => {
      console.log(res);
      console.log(res.data);

      setDeleteModal({ id: "", name: "", show: !deletemodal.show });
      toast.success("Loan Deleted Successfully ", {
        position: toast.POSITION.BOTTOM_LEFT,
        autoClose: 3000,
      });
    });
  };
  const onValueChange = (e) => {
    const name = e.target.name;
    const value = e.target.value;
    setformInputs((values) => ({ ...values, [name]: value }));
  };
  const editOrder = (edit) => {
    users.map((ord) => {
      if (ord.id === edit.id) {
        setformInputs({ id: ord.id, reason: ord.reason, status: ord.status });
        setShow(true);
      }
    });
  };
  const handleEdit = () => {
    let data = {
      reason: formInputs.reason,
      status: formInputs.status,
    };
    Axios.put(`http://localhost:8080/api/loans/${formInputs.id}`, data).then(
      function (response) {
        setShow(!show);
        toast.success("Loan Edited Successfully ", {
          position: toast.POSITION.BOTTOM_LEFT,
          autoClose: 3000,
        });
      }
    );
  };
  return (
    <div className="total">
      <Row>
        <Col sm="3" className="sidebar">
          <Sidebar />
        </Col>
        <Col
          style={{
            paddingRight: "50px",
            paddingLeft: "50px",
            paddingTop: "40px",
          }}
        >
          <Container>
            <div style={{ fontSize: "25px" }}>
              Welcome{" "}
              <b>
                {info.fname} {info.lname}
              </b>
            </div>
            <br></br>
            <TableContainer>
              <Table sx={{ minWidth: "50px" }} aria-label="customized table">
                <TableHead>
                  <StyledTableRow>
                    <StyledTableCell align="center"> Id</StyledTableCell>
                    <StyledTableCell align="center">
                      Purpose of loan
                    </StyledTableCell>
                    <StyledTableCell align="center">Status</StyledTableCell>
                    <StyledTableCell align="center">options</StyledTableCell>
                  </StyledTableRow>
                </TableHead>
                <TableBody>
                  {users.map((row) => (
                    <StyledTableRow key={row.id}>
                      <StyledTableCell align="center">{row.id}</StyledTableCell>
                      <StyledTableCell align="center">
                        {row.reason}
                      </StyledTableCell>
                      <StyledTableCell align="center">
                        {row.status}
                      </StyledTableCell>
                      <StyledTableCell align="center">
                        <Button
                          variant="primary"
                          onClick={() => editOrder(row)}
                        >
                          edit
                        </Button>
                        <Button
                          variant="success"
                          onClick={() => deleteOrder(row.id, row.reason)}
                        >
                          Delete
                        </Button>
                      </StyledTableCell>
                    </StyledTableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </Container>
        </Col>
      </Row>

      {/* pop-up for edit order */}

      <Modal show={show} onHide={handleClose}>
        <Modal.Header>
          <Modal.Title className="modaltitle">Edit Loan</Modal.Title>
        </Modal.Header>
        <Modal.Body style={{ maxHeight: "400px" }} className="modalform">
          <Form>
            <Form.Group class="form-group required" controlId="formUser">
              <Form.Label class="control-label">Reason</Form.Label>
              <Form.Control
                type="text"
                placeholder="enter the reason"
                value={formInputs.reason}
                name="reason"
                onChange={(e) => onValueChange(e)}
                autoFocus
              />
            </Form.Group>
            <Form.Group class="form-group required" controlId="formUser">
              <Form.Label class="control-label">Status</Form.Label>
              <Form.Control
                type="text"
                placeholder="enter the status"
                value={formInputs.status}
                name="status"
                onChange={(e) => onValueChange(e)}
                autoFocus
              />
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="primary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="warning" onClick={handleEdit}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>

      {/* pop-up for delete order */}

      <Modal
        show={deletemodal.show}
        onHide={() =>
          setDeleteModal({ id: "", reason: "", show: !deletemodal.show })
        }
      >
        <Modal.Title>Confirm Delete</Modal.Title>
        <Modal.Body>
          <Row>
            <Col>
              <p>
                Are you sure to delete Loan: <b>{deletemodal.id}?</b>
              </p>
            </Col>
          </Row>

          <Row>
            <Col sm={{ offset: 7, span: 2 }}>
              <Button
                variant="danger"
                onClick={() => handleDelete(deletemodal.id, deletemodal.reason)}
              >
                Delete
              </Button>
            </Col>
            <Col sm={{ span: 3 }}>
              <Button
                variant="secondary"
                onClick={() =>
                  setDeleteModal({
                    id: "",
                    reason: "",
                    show: !deletemodal.show,
                  })
                }
              >
                Cancel
              </Button>
            </Col>
          </Row>
        </Modal.Body>
      </Modal>
    </div>
  );
}
