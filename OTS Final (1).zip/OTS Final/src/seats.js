import React from 'react'
import {Card,Row,Col,Container,Button} from 'react-bootstrap'
import './seats.css'

const seats = () => {
  return (

    <div>
        <div className='title'>
    <Card.Title>add new booking</Card.Title></div>

   
<Card className='first'>
<Card.Body>
        <Container>
        <Row>
        <Col sm={6}>hii</Col>

        <Col sm={6}>
        <Card.Title>Booking Details</Card.Title>
        <Card.Title>Selected seats</Card.Title>
        <Card.Body> </Card.Body>
        Total: $ <br></br>
        <button>Checkout</button><br></br>
        <Button>cancel</Button>
        </Col>
        </Row>
        </Container>

    
   </Card.Body>
</Card>



</div>

  )
}

export default seats
