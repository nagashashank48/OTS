import React, { useEffect, useState } from 'react'
import { Row, Col, Card, Button, Container, Modal } from 'react-bootstrap'
import "./styles.css"
import axios from 'axios'
import $ from 'jquery'
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useSelector ,useDispatch } from 'react-redux'

toast.configure()

const BookingPage = (props) => {
  const dispatch=useDispatch();
  
  const selectauthToken = (rootstate) => rootstate.authToken
   const authToken = useSelector(selectauthToken)
  //console.log(authToken);
  const seatNum = [];
  // state = {
  //     listSeat: [],
  //   };
  const [seats, setSeat] = useState([])
  

  const [order, setOrder] = useState({
    "username":"",
    "movie": "",
    "tickets": "",
    "total": "",
    "created": "2019-02-07T04:30:00Z"
  })
  
  const [sseats, setSseat] = useState([{ rowname: "A", seats: [{ title: 1, stat: "booked" }, 2, 3] }]);
  const [sseatss, setSseats] = useState([{ rowname: "A", seats: [{ title: 1, stat: "booked" }, 2, 3] }]);
  //var columns=sseats[0].seats.length;

  //console.log(columns);
  useEffect(() => {
    //const arr=['A1','A2']
    //arr.map(item=>(
    //$("td[name="+item + "]").css('background-color','red')
    //$("#"+item).css('background-color','red')
    //$("#"+item).attr ('disabled','true')
    //$("#"+item).style.setProperty("background-color", "red")
    //$("#A2").style.background-color  "green"
    //  var obj = document.getElementById("A2")

    //  obj.style.setProperty("background-color", "red")

    //) );
    //$("td[name= 'A1']" ).css('backgroundColor','red')
    //$("#A2").attr ('disabled','true'); 
    if(seats.length>5)
    {
      let a=seats.splice(0,1)
      console.log(a)
      //$("#A2").attr("className", "seat-available");
      //$("#A2").toggleClass(' seat-available');
      $('#'+a).removeClass('seat-selected').addClass('seat-available');

    }
    axios.get(`http://localhost:8080/api/sseats`,).then(res => {



      setSseats(res.data)

      setSseat(res.data)

    })

  }

    , [seats]);
  var rows = sseats.length;
  var col = sseats[0].seats.length
  console.log(rows);
  console.log(sseats[0])
  console.log(col)


  const savechanges = () => {
   if(seats.length===0)
   {
    toast.error('Select atleast 1 seat ', { position: toast.POSITION.BOTTOM_LEFT, autoClose: 3000 })
   } 
   else{
     let details={
    "username":authToken.email,
    "movie": props.movie,
    "tickets":seats.length,
    "total": totalcost(),
    "created": "2019-02-07T04:30:00Z"}
   //console.log(await getOrder());
  //  setOrder((state) => {
  //   console.log(state); // "React is awesome!"
  //   return state;
  // });
    let arr1=[]
    arr1=[...sseatss];
    seats.map(item=>{
      console.log(item.charAt(0))
      let s=item.charAt(0).charCodeAt(0)-65
      arr1[s].seats[item.charAt(1)-1].stat="booked" 
      })
      console.log(arr1)
      let i=0;
      arr1.map(item=>{
        
      
      //let arr2=arr1[0]
    axios.put(`http://localhost:8080/api/sseats/${sseats[i].id}`, item )
    .then(function (response) {
     console.log(response);
      
     
    })
    i=i+1;
  })
  
     
  
    toast.success('Tickets Booked Successfully', { position: toast.POSITION.BOTTOM_LEFT, autoClose: 3000 })

     
     setSeat([])
     props.method(!props.show)
     //console.log(order);
     
    axios.post(`http://localhost:8080/api/aorders`, details)
    
    
  }
 
 }
 
//console.log(order);
  
  
  //console.log(order)
  const handleClick = (e) => {
    // console.log( e.target.className)
    const checked = e.target.checked;
    if (e.target.className === "seat-available") {
      //checked
      //console.log("checked" + e.target.value)
      e.target.className = "seat-selected"
      setSeat([...seats, e.target.id])


      // console.log( e.target.id)
    }
    else if (e.target.className === "seat-selected") {
      //checked
      //console.log("checked" + e.target.value)
      e.target.className = "seat-available"
      var array = seats;
      var index = array.indexOf(e.target.id);
      array.splice(index, 1);
      //setSeat(array)
      setSeat([...array])





    }


    // else  {
    //   var array = seats;
    //   var index = array.indexOf(e.target.value); 
    //   //delete array[index];
    //   array.splice(index,1);
    //   setSeat(array)
    //   setSeat([...seats])

    //  //unchecked
    //  console.log("notchecked" + e.target.value)
    // }


    // });
    // let { name, checked } = e.target;
    // setSeat(
    //   (e) => {
    //     let selectedSeat = e.listSeat;
    //     return (selectedSeat[name] = checked);
    //   },
    // () => {
    //   this.props.createSeat(
    //     Object.keys(seats.listSeat)
    //       .filter((x) => seats.listSeat[x])
    //       .join(", ")
    //   );
    // }
    // );
  };
  console.log(seats)
  console.log(sseats[0].seats[0].stat)
  //const seatNum = [];
  for (let i = 1; i < col + 1; i++) {
    if (i === 4) {
      seatNum.push(<div className="px-3"></div>);
    }
    seatNum.push(<td className="pl-3">{i}</td>);
  }
  let k = "A";
  const seatA = [];
  for (let j = 0; j < rows; j++) {
    for (let i = 1; i < col + 1; i++) {
      if (i === 4) {
        seatA.push(<div className="px-3"></div>);
      }

      seatA.push(
        <td>
          {/* <input
          type="checkbox" */}
          <div
            //const drink = dislikeCoke ? 'fanta' : likesCherry ? 'cherryCoke' : 'dietCoke';
            className={(sseats[j].seats[i - 1].stat === "booked") ? "seat-booked" : (sseats[j].seats[i - 1].stat === "available") ? "seat-available" : "seat-selected"}
            value={`${k}${i}`}
            name={`${k}${i}`}
            id={`${k}${i}`}
            disabled={(sseats[j].seats[i - 1].stat === "booked") ? true : false}
            onClick={(event) => handleClick(event)}


          >
          </div>


        </td>

      );
    }
    k = String.fromCharCode(k.charCodeAt(0) + 1);
  }








  const totalcost = () => {
    return (seats.length * 250)

  }
  let result = []

  for (let i = 0; i < seatA.length; i += col + 1) {
    result.push(seatA.slice(i, i + col + 1));
  }
  console.log(result)
  //var abc = [];
  // for (var i = 0; i < rows; i++) {
  //     // note: we are adding a key prop here to allow react to uniquely identify each
  //     // element in this array. see: https://reactjs.org/docs/lists-and-keys.html
  //     abc.push(seatA.splice(0,6) );
  //     abc.push(seatA.splice(0,6) );
  // }
  // return <tbody>{abc}</tbody>;


  let z = 'A'
  // const rowv=()=>{
  //   console.log(z)
  //      z= String.fromCharCode(z.charCodeAt(0)+1)
  //      return z;

  // }




  return (


   
    <Modal show={props.show} onHide={props.handleClose} size="lg"
      aria-labelledby="contained-modal-title-vcenter"
      centered>
      <Modal.Header style={{ backgroundColor: '#1266F1', color: 'white', fontSize: '30px' }}>
        <Modal.Title id="contained-modal-title-vcenter">Add New Booking</Modal.Title>
      </Modal.Header>
      
      <Modal.Body style={{ overflowY: "scroll", maxHeight: "400px" }}>
        <Container >
          <Card>

            <Row>

              <Col>
                <Card className="border-0 p-5 order-seat">
                  <Card.Body className="row text-center">
                    <Col xs={11} className="">
                      <p className="text-link-xs" style={{ fontWeight: "bold" }}>Screen</p>
                      <div className="line-screen"></div>
                    </Col>
                  </Card.Body>
                  <Card.Body>

                  </Card.Body>
                </Card>
                <table style={{ alignContent: 'center', marginLeft: '40px' }}>

                  <tbody>
                    {result.map((item, index) => (
                      <tr>

                        <td>{String.fromCharCode(z.charCodeAt(0) + index)}</td>
                        {item}

                      </tr>

                    )
                    )}<tr>
                      <td></td>
                      {seatNum}
                    </tr>




                  </tbody>
                </table>

              </Col>




              <Col>
                <p className="text-display-xs-bold" style={{ fontWeight: "bold", fontSize: '23px' }}>Booking Details</p>
                <p className="text-display-xs-bold" style={{ fontWeight: "bold" }}>Movie Name :{props.movie} </p>
                <p className="text-display-xs-bold" style={{ fontWeight: "bold" }}>Selected Seats  ({seats.length}) : {seats + ' '}</p>
                <p className="text-display-xs-bold" style={{ fontWeight: "bold",color:"red" }}>Note : You can select only 5 seats at once.</p>
                
                {/* <p>economy class tickets (1):$100</p>
      
      
      <p>first class tickets (2):- $50</p>
       */}
                <p style={{ fontWeight: "bold" }}>Total : {totalcost()}</p>
                <div className="pt-4 checkout">


                  <Button
                    variant="primary shadow"
                    className="float-right col-12 col-md-5"
                  >
                    Checkout now
                  </Button>

                </div>

                <p className="text-link pt-4" style={{ fontWeight: "bold" }}>Seating key</p>
                <Row>
                  <Col sm={5} style={{display:"flex"}}>

                  <div className="seat-available "></div>{'     '}
                  
                  <p> Available</p>
                  </Col>
                </Row>
                <Row>
                  <Col sm={5} style={{display:"flex"}}>

                  <div className="seat-selected float-left mr-3"></div>
                  <p>Selected</p>
                  </Col>
                </Row>

                <Row>
                <Col sm={5} style={{display:"flex"}}>

                  <div className="seat-booked float-left mr-3"></div>
                  <p>Sold</p></Col>
                </Row>


              </Col>
            </Row>
          </Card>
        </Container>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={props.handleClose}>
          Close
        </Button>
        <Button variant="primary" onClick={()=>savechanges()}>
          Save Changes
        </Button>
      </Modal.Footer>
    </Modal>
  )
}

export default BookingPage
