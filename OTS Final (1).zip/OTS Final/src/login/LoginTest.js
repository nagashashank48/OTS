import React from 'react'
import { useFormik } from 'formik'
import './LoginTest.css'
const LoginTest = () => {
    const formik=useFormik({
        initialValues:{
            email:'',
            password:''
        },
        onSubmit:(values)=>{
            let count = 0;
      let backenderrors = {};
      json_userdetails.forEach((user) => {
        if (user.email === inputs["email"]) {
          count = count + 1;
          if (user.password === inputs["password"]) {
            dispatch({type:"SETAUTHTOKEN", data:{email:user.email, role:user.role,id:user.id}});
          }

          else {
            backenderrors["password"] = "Incorrect Password";
          }
        }
      });
      if (count === 0) {
        backenderrors["email"] = "No such email exists";
      }
      setErrors(backenderrors);
         console.log(values)
         },
         validate:(values)=>{
             let errors={};
             if(!values.email)
             {
                 errors.email="Email Required"
             }
             if(!values.password)
             {
                 errors.password="Password Required"
             }
             return errors;
         }
        }
        )
      return (
        
        <form autoComplete="off" onSubmit={formik.handleSubmit}>


          <div class="form-group required">
          <label for="email" class='control-label'>Email Address:</label>
          <input type="text"
              name="email" 
              value={formik.values.email} 
              onChange={formik.handleChange}
              class="form-control"
              placeholder="Enter email"
              id="email"></input>
              <br/>
          {formik.errors.email?<div className="errors">{formik.errors.email}</div>:null}
          </div>  


          <div class="form-group required">
            <label for="password" class='control-label'>Password:</label>
          <label>Password:</label>
          <input type="password"  
          name="password" 
          value={formik.values.password}
          onChange={formik.handleChange} 
          class="form-control"
          placeholder="Enter password"
          id="password">
              </input><br/>
          {formik.errors.password?<div className="errors">{formik.errors.password}</div>:null}
          </div>  

          <button type="submit">Login</button>
          </form>
    
      )
    }

export default LoginTest


