import React from 'react'
import {Card,Button,Form,Row,Col,Container} from 'react-bootstrap';
import './register.css'
import axios from 'axios';
import {useState} from 'react'
import {toast} from 'react-toastify';
import {Link} from 'react-router-dom'
import 'react-toastify/dist/ReactToastify.css';
import configData from '../config'

toast.configure()
function Register() {
   const [inputs,setinputs]=useState({"role":"USER"})
   const [errors, setErrors] = useState({});
  
  
   const handleChange = event => {
   

    setinputs(values=>({...values,[event.target.name]:event.target.value}));
  } 
  const handleSubmit = event => {
    event.preventDefault();
    
    if (validate()) {
  
  let details={...inputs,"role":"USER"}
  
    console.log(inputs)
    axios.post(`http://localhost:8080/api/users`,details)
    
      .then(res => {
        
        console.log(inputs)
        setinputs({})
        toast.success('Registration successful', {position: toast.POSITION.BOTTOM_LEFT,autoClose:3000})
      })}}


      const validate = () => {

        let isValid = true;
        let error = {};
    
        if (!inputs["name"]) {
          isValid = false;
          error["name"] = "Please enter your name.";
        }
        if (!inputs["email"]) {
          isValid = false;
          error["email"] = "Please enter your email.";
        }
        if (typeof inputs["email"] !== "undefined") {

          var pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
          if (!pattern.test(inputs["email"])) {
            isValid = false;
            error["email"] = "Please enter valid email address.";
          }
        }
        if (!inputs["password"]) {
          isValid = false;
          error["password"] = "Please enter your password.";
        }
        if (typeof inputs["password"] !== "undefined") {
          if (inputs["password"].length < 6) {
            isValid = false;
            error["password"] = "Please add at least 6 character.";
          }
        }
        if (!inputs["gender"]) {
          isValid = false;
          error["gender"] = "Please select gender.";
        }
        if (!inputs["age"]) {
          isValid = false;
          error["age"] = "Please select your age.";
        }
        // console.log(error);
        setErrors(error);

    return isValid;
  }
  const validName=()=>{
    let error=""
    if (!inputs["name"]) {  
        error = "Please enter name.";
    }

    else {
        if (inputs["name"].length < 3) {
            error = "Please add at least 3 character.";
        }
    }
    setErrors(values => ({ ...values, name:error}))

}
const validEmail=()=>{
  let error=""
  if (!inputs["email"]) {
      
      error= "Please enter your email Address.";
  }

  else {
      var pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
      if (!pattern.test(inputs["email"])) {
          
          error= "Please enter valid email address.";
      }
  }
  setErrors(values => ({ ...values, email:error}))
}
const validPassword=()=>{
  let error=""
  if (!inputs["password"]) {  
      error = "Please enter password.";
  }

  else {
      if (inputs["password"].length < 6) {
          error = "Please add at least 6 character.";
      }
  }
  setErrors(values => ({ ...values, password:error}))

}
const validGender=()=>{
  let error=""
  if (!inputs["gender"]) {  
      error = "Please enter gender.";
  }

  setErrors(values => ({ ...values, gender:error}))

}
const validAge=()=>{
  let error=""
  if (!inputs["age"]) {  
      error = "Please enter age.";
  }

  setErrors(values => ({ ...values, age:error}))

}


  return (
    <Container >
      <title>{configData.TITLE.APP_TITLE}</title>
         <div className="abc">
         <Row>
    <Col sm={4}></Col>
    <Col sm={4}>  
      <Card  style={{color:'white', width: '25rem' }}>
     {/* <Card.Title className='register'>REGISTER HERE</Card.Title> */}
     <Card.Header className='register' style={{backgroundColor:"#1266F1"}}><b>REGISTER HERE</b></Card.Header>
  <Card.Body style={{backgroundColor:'rgb(212, 237, 245)'}}>
      <Form onSubmit={handleSubmit}>
      <Form.Group className="mb-3" >
      <div className="form-group required">
    <Form.Label className='control-label'>Name</Form.Label>
    <Form.Control  onBlur={validName} type="text" placeholder="Enter name"  name="name" onChange={handleChange} />
    {errors.name?<div className="errors">{errors.name}</div>:null}</div>
  </Form.Group>

  <Form.Group className="mb-3">
  <div className="form-group required">
    <Form.Label className='control-label'>Email address</Form.Label>
    <Form.Control onBlur={validEmail} type="email"  placeholder="Enter email" name="email" onChange={handleChange} />
    {errors.email?<div className="errors">{errors.email}</div>:null}</div>
  </Form.Group>

  <Form.Group className="mb-3" >
  <div className="form-group required">
    <Form.Label className='control-label'>Password</Form.Label>
    <Form.Control onBlur={validPassword} type="password" placeholder="Password" name="password" onChange={handleChange}/>
    {errors.password?<div className="errors">{errors.password}</div>:null}</div>
  </Form.Group>

  <Form.Group className="mb-3" >
  <div className="form-group required">
  <Form.Label className='control-label'>Gender</Form.Label>
  <Form.Check onBlur={validGender}
        type="radio"
        id="default-radio-male"
        label="male" name="gender" value="Male" onChange={handleChange}
        
      />
      
      <Form.Check 
        type="radio"
        id="default-radio-female"
        label="female" name="gender" value="Female" onChange={handleChange}
        
      />{errors.gender?<div className="errors">{errors.gender}</div>:null}</div>
       
  </Form.Group>

  <Form.Group className="mb-3" >
  <div className="form-group required">
    <Form.Label className='control-label'>Age</Form.Label>
    <select onBlur={validAge} className="form-control" name="age" onChange={handleChange}>
                                        <option value="">Select age</option>
                                        <option value="20-30">20-30</option>
                                        <option value="30-40">30-40</option>
                                        <option value="40 and above">40 and above</option>
                                    </select>
                                    {errors.age?<div className="errors">{errors.age}</div>:null}</div>
  </Form.Group>
  
<Button type='submit' > Register</Button>{"   "}
<Button type="reset"  >Reset</Button>{"  "}
<Button type='button' variant="secondary"><Link to="/"  style={{textDecoration:"none",color:"white"}}>Back</Link></Button>
  
  
</Form>

  </Card.Body>

</Card></Col>
</Row>

        </div>
        </Container>
  )
}

export default Register
