import React from 'react'
import { useEffect, useMemo, useState } from "react";
import axios from "axios";
import { useTable, usePagination, useGlobalFilter } from "react-table";
import { Table, Button, Row, Col, Container, Card, Form, Modal } from "react-bootstrap";
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import './AdminManageOrders.css'
import dateFormat from 'dateformat';
import configData from "../../config.json";
import $ from 'jquery'

toast.configure()
const AdminManageScreens = () => {
  const [orders, setData] = useState([]);
  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleCloseAdd = () => setShowadd(false);
 
  const [deletemodal, setDeleteModal] = useState({ id: "", screenname: "", show: false })
  const [showadd, setShowadd] = useState(false);
  const [errors, setErrors] = useState({});

  const [effectrunner, setEffectRunner] = useState(false);
  const [formInputs, setformInputs] = useState({ screenname: "", totalrows: "", totalcolumns: '', totalseats: '' });

  const editOrder = (edit) => {
    axios.get(`http://localhost:8080/api/screens/${formInputs.id}`)
    orders.map((ord) => {
      if (ord.id === edit.id) {

        setformInputs({ id: ord.id, screenname: ord.screenname, totalseats: ord.totalseats, created: ord.created })
        setShow(true)
      }
    })
  }
  const handleAddModal = () => {
    setformInputs({ screenname: "", totalrows: "", totalcolumns: ""})
    setShowadd(true)
  }
  
  const onValueChange = (e) => {
    
    
    const name = e.target.name;
    const value = e.target.value;
    setformInputs(values => ({ ...values, [name]: value }))

  }

  function add_number() {
 
 
     $('#totalseats').val($('#totalrows').val() * $('#totalcolumns').val());
  }


  const deleteScreen = (id, screenname) => {
    setDeleteModal({ id: id, screenname: screenname, show: !deletemodal.show })
}

const handleDelete = (id,screenname) => {

  
      axios.delete(`http://localhost:8080/api/screens/${id}`)
          .then(res => {
              console.log(res);
              console.log(res.data);
              setEffectRunner(!effectrunner);
              setDeleteModal({id:"",screenname:"",show:!deletemodal.show})
              toast.success(res.data.message, { position: toast.POSITION.BOTTOM_LEFT, autoClose: 3000 })
          })
  
}


  


  const handleEdit = () => {
     if (validateEdit()) {
    let editdata = {
      screenname: formInputs.screenname, totalseats: formInputs.totalseats, id: formInputs.id
    }


    console.log(editdata);
    axios.put(`http://localhost:8080/api/screens/${formInputs.id}`, editdata)
      .then(function (response) {
        console.log(response);
        setShow(!show);
        toast.success(response.data.message, { position: toast.POSITION.BOTTOM_LEFT, autoClose: 3000 })
      })

     }
  }
  const handleSubmit = event => {
    event.preventDefault();
    if (validate()) {
     
      axios.post(`http://localhost:8080/api/screens`, { ...formInputs, totalseats:$('#totalseats').val()  })
        .then(res => {
          
          setformInputs({})
          setShowadd(!showadd)
          toast.success("Screen added successfully", { position: toast.POSITION.BOTTOM_LEFT, autoClose: 3000 })
        })
    }
  }


  const validateEdit = () => {

    let isValid = true;
    let error = {};

    if (!formInputs["screenname"]) {
      isValid = false;
      error["screenname"] = "Please enter screen name.";
    }

    
    if (!formInputs["totalseats"]) {
      isValid = false;
      error["totalseats"] = "Please enter total seats.";
    }
    
    setErrors(error);

    return isValid;
  }












  const validate = () => {

    let isValid = true;
    let error = {};

    if (!formInputs["screenname"]) {
      isValid = false;
      error["screenname"] = "Please enter screen name.";
    }

    if (!formInputs["totalrows"]) {
      isValid = false;
      error["totalrows"] = "Please enter total rows.";
    }

    if (!formInputs["totalcolumns"]) {
      isValid = false;
      error["totalcolumns"] = "Please enter total columns.";
    }
   
    setErrors(error);

    return isValid;
  }
  const validScreenName=()=>{
    let error=""
    if (!formInputs["screenname"]) {  
        error = "Please enter screenname.";
    }

    else {
        if (formInputs["screenname"].length < 1) {
            error = "Please add at least 1 character.";
        }
    }
    setErrors(values => ({ ...values, screenname:error}))

}
const validRow=()=>{
  let error=""
  if (!formInputs["totalrows"]) {  
      error = "Please enter totalrows.";
  }

  
  setErrors(values => ({ ...values, totalrows:error}))

}
const validColumn=()=>{
  let error=""
  if (!formInputs["totalcolumns"]) {  
      error = "Please enter totalcolumns.";
  }

  
  setErrors(values => ({ ...values, totalcolumns:error}))

}
const validSeats=()=>{
  let error=""
  if (!formInputs["totalseats"]) {  
      error = "Please enter totalseats.";
  }

  
  setErrors(values => ({ ...values, totalseats:error}))

}


  
  









  const COLOMUNS = [
    {
      Header: "ID",
      accessor: "id",
    },
    {
      Header: "Screen Name",
      accessor: "screenname",
    },
    {
      Header: "Total Seats",
      accessor: "totalseats",
    },
    {
      Header: "Created",
      accessor: "createdAt",
    }
  ];

  useEffect(() => {
    const fetchTd = async () => {
      await axios
        .get(`http://localhost:8080/api/screens`)
        .then((res) => {
          const ord = [...res.data];
          setData(ord);
        });
    };
    fetchTd();
  }, [show, effectrunner,showadd]);


  const updatedList = orders.map(item => 
    {
        
        return {...item, createdAt:dateFormat(item.createdAt,configData.DATE_FORMAT,true)}
        
    })


  
  const columns = useMemo(() => COLOMUNS, []);
  const data = useMemo(() => updatedList, [orders]);

  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    page,
    nextPage,
    previousPage,
    canPreviousPage,
    canNextPage,
    pageOptions,
    state,
    setGlobalFilter,
    setPageSize,
    prepareRow,
  } = useTable(
    {
      columns,
      data,
      initialState: { pageIndex: 0 },
    },
    useGlobalFilter,
    usePagination
  );

  const { pageIndex, pageSize, globalFilter } = state;

  return (
    <>
      <Container>
      <title>{configData.TITLE.SCREENS}</title>
        <Row>
          <Card
            style={{ width: "15rem", marginLeft: "20px", marginTop: "20px" }}
          >
            <Card.Body style={{fontSize:"20px"}}>
              <b>Manage Screens</b>
            </Card.Body>
          </Card>
        </Row>
        <Row>
          <Col sm={3}></Col>
          <Col sm={5}>
            <input
              class="form-control"
              placeholder="Search Screens"
              value={globalFilter || ""}

              onChange={(e) => setGlobalFilter(e.target.value)}
            ></input>
          </Col>
          <Col>
            <Button variant="primary" onClick={handleAddModal} style={{float:"right"}}>Add New Screen</Button>
          </Col>
        </Row>

        {/* popupwindow for add */}

        <Modal show={showadd} onHide={handleCloseAdd}>
          <Modal.Header  style={{backgroundColor:"#1266F1"}}>
            <Modal.Title className='modaltitle' >Add New Screen</Modal.Title>
          </Modal.Header>
          <Modal.Body style={{ overflowY: "scroll", maxHeight: "400px" }} className='modalform'>
            <Form onSubmit={handleSubmit}>
              <Form.Group className="mb-3" >
                <div class="form-group required">
                  <Form.Label class='control-label'> Screen Name</Form.Label>
                  <Form.Control  onBlur={validScreenName} type="text" placeholder="Screen Name" id="screennames" name="screenname" onChange={(e) => onValueChange(e)} />
                  {errors.screenname ? <div className="errors">{errors.screenname}</div> : null}</div>
              </Form.Group>

              <Form.Group className="mb-3">
                <div class="form-group required">
                  <Form.Label class='control-label'>Total Rows</Form.Label>
                  <Form.Control onBlur={validRow} type="number" placeholder="Total Rows" id="totalrows" name="totalrows" oninput={add_number()} onChange={(e) => onValueChange(e)} />
                  {errors.totalrows ? <div className="errors">{errors.totalrows}</div> : null}</div>
              </Form.Group>

              <Form.Group className="mb-3">
                <div class="form-group required">
                  <Form.Label class='control-label'>Total Columns</Form.Label>
                  <Form.Control onBlur={validColumn} type="number" placeholder="Total Columns" id="totalcolumns" name="totalcolumns" oninput={add_number()} onChange={(e) => onValueChange(e)} />
                  {errors.totalcolumns ? <div className="errors">{errors.totalcolumns}</div> : null}</div>
              </Form.Group>

              <Form.Group className="mb-3" >
                <div class="form-group required">
                  <Form.Label class='control-label'>Total Seats</Form.Label>
                   <Form.Control readOnly type="totalseats" placeholder="Total Seats" name="totalseats" id="totalseats" onChange={(e) => onValueChange(e)} />
                 {/* {errors.totalseats ? <div className="errors">{errors.totalseats}</div> : null} */}
                  </div> 
              </Form.Group>




            </Form>

          </Modal.Body>
          <Modal.Footer style={{backgroundColor:"#1266F1"}}>
            <Button variant="secondary" onClick={handleCloseAdd}>
              Close
            </Button>
            <Button variant="warning" onClick={handleSubmit}>
              Add
            </Button>
          </Modal.Footer>
        </Modal>


{/* pop for edit */}


        <Modal show={show} onHide={handleClose}>
          <Modal.Header style={{backgroundColor:"#1266F1"}}>
            <Modal.Title className='modaltitle' >Edit Screen</Modal.Title>
          </Modal.Header>
          <Modal.Body style={{ overflowY: "scroll", maxHeight: "400px" }} className='modalform'>
            <Form >
              <Form.Group class="form-group required" controlId="formUser">
                <Form.Label class='control-label'>Screen Name</Form.Label>
                <Form.Control onBlur={validScreenName}
                  type="text"
                  placeholder="ScreenName"
                  value={formInputs.screenname}
                  name="screenname"
                  onChange={(e) => onValueChange(e)}
                  autoFocus
                />{errors.screenname ? <div className="errors">{errors.screenname}</div> : null}
              </Form.Group>
              <Form.Group class="form-group required" controlId="formMovie">
                <Form.Label class='control-label'>Total Seats</Form.Label>
                <Form.Control onBlur={validSeats}
                  type="type"
                  placeholder="Total Seats"
                  value={formInputs.totalseats}
                  name="totalseats"
                  onChange={(e) => onValueChange(e)}
                />{errors.totalseats ? <div className="errors">{errors.totalseats}</div> : null}
              </Form.Group>
             


            </Form>
          </Modal.Body>
          <Modal.Footer style={{backgroundColor:"#1266F1"}}>
            <Button variant="secondary" onClick={handleClose}>
              Close
            </Button>
            <Button variant="warning" onClick={handleEdit}>
              Save Changes
            </Button>
          </Modal.Footer>
        </Modal>

        {/* Modal for delete  */}
        <Modal show={deletemodal.show} onHide={() =>setDeleteModal({ id: "", screenname: "", show: !deletemodal.show })}>
                       
        <Modal.Title>Confirm Delete</Modal.Title>
                        <Modal.Body>
                            <Row>
                                <Col>
                                    <p>Are you sure to delete screen: <b>{deletemodal.screenname}?</b></p>
                                </Col>
                            </Row>

                            <Row>
                                <Col sm={{ offset: 7, span: 2 }}>
                                    <Button variant="danger" onClick={() => handleDelete(deletemodal.id, deletemodal.screenname)}>Delete</Button>
                                </Col>
                                <Col sm={{ span: 3 }}>
                                    <Button variant="secondary" onClick={() => setDeleteModal({ id: "", screenname: "", show: !deletemodal.show })}>Cancel</Button>
                                </Col>
                            </Row>
                        </Modal.Body>
                    </Modal>














        <div style={{overflowX:"auto"}}> 
        <Table
          bordered
          hover
          style={{ marginTop: "30px" }}
          {...getTableProps()}
        >
          <thead style={{ backgroundColor: "#1266F1", color: "white" }}>
            {headerGroups.map((headerGroup) => (
              <tr {...headerGroup.getHeaderGroupProps()}>
                {headerGroup.headers.map((column) => (
                  <th {...column.getHeaderProps()}>
                    {column.render("Header")}
                  </th>
                ))}
                <th>Action</th>
              </tr>
            ))}
          </thead>
          <tbody
            {...getTableBodyProps()}
            style={{ backgroundColor: "rgb(212, 237, 245)" }}
          >
            {page.map((row) => {
              prepareRow(row);
              return (
                <tr {...row.getRowProps()}>
                  {row.cells.map((cell) =>
                  (
                    <td {...cell.getCellProps()}>{cell.render("Cell")}</td>
                  )
                  )}
                  <td> <Button variant="warning" onClick={() => editOrder(row.values)}>Edit</Button>{'      '}<Button variant="danger" onClick={() => deleteScreen(row.values.id, row.values.screenname)}>Delete</Button>  </td>
                </tr>
              );
            })}
          </tbody>
        </Table>
        </div>  
        <div>
          <Row>
            <Col sm={8}></Col>
            <Col>
              <Button
                variant="primary"
                onClick={() => previousPage()}
                disabled={!canPreviousPage}
              >
                Previous
              </Button>{" "}
              <span>
                Page{" "}
                <strong>
                  {pageIndex + 1} of {pageOptions.length}
                </strong>{" "}
              </span>
              <select
                value={pageSize}
                onChange={(e) => setPageSize(Number(e.target.value))}
              >
                {[5, 10, 50].map((pageSize) => (
                  <option key={pageSize} value={pageSize}>
                    Show {pageSize}
                  </option>
                ))}
              </select>{" "}
              <Button
                variant="primary"
                onClick={() => nextPage()}
                disabled={!canNextPage}
              >
                Next
              </Button>
            </Col>
          </Row>
        </div>
      </Container>
    </>
  );
};
export default AdminManageScreens