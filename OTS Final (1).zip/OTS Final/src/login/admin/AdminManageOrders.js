import React from 'react'
import { useEffect, useMemo, useState } from "react";
import axios from "axios";
import { useTable, usePagination, useGlobalFilter } from "react-table";
import { Table, Button, Row, Col, Container, Card,Form,Modal } from "react-bootstrap";
import {toast} from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import './AdminManageOrders.css'
import BookingPage from '../user/BookingPage'
import dateFormat from 'dateformat';
import {Link} from "react-router-dom"
import configData from "../../config.json";
toast.configure()
const AdminManageOrders = () => {
  const [Addshow, setAddShow] = useState(false);
  const handleAddClose = () => setAddShow(false);
  const handleAddShow = () =>setAddShow(true)
  const [deletemodal, setDeleteModal] = useState({ id: "", show: false }) 

        const [orders, setData] = useState([]);
        const [errors, setErrors] = useState({});
    const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
 
  const [effectrunner, setEffectRunner] = useState(false);
  const [formInputs,setformInputs]=useState({id:"",username:"",movie:'',tickets:'',total:'',created:''})
  const editOrder=(edit)=>{
  axios.get(`http://localhost:8080/api/aorders/${formInputs.id}`)
    
        orders.map((ord)=>{
            if(ord.id===edit.id){
                
                setformInputs({id:ord.id,username:ord.username,movie:ord.movie,tickets:ord.tickets,total:ord.total,created:ord.created}) 
               
                setShow(true)
            }
        })
      }

 const onValueChange = (e) => {

    const name = e.target.name;
        const value = e.target.value;
        setformInputs(values => ({ ...values, [name]: value }))

}

const deleteOrder = (id) => {
  setDeleteModal({ id: id, show: !deletemodal.show })
}

const handleDelete = (id) => {


    axios.delete(`http://localhost:8080/api/aorders/${id}`)
        .then(res => {
            console.log(res);
            console.log(res.data);
            setEffectRunner(!effectrunner);
            setDeleteModal({id:"",name:"",show:!deletemodal.show})
            toast.success( res.data.message, { position: toast.POSITION.BOTTOM_LEFT, autoClose: 3000 })
        })

}

const handleEdit = () => {
     if (validate()) {
         let editdata = {
            username:formInputs.username,movie:formInputs.movie,tickets:formInputs.tickets,total:formInputs.total
            }

        console.log(editdata);
        axios.put(`http://localhost:8080/api/aorders/${formInputs.id}`,editdata)
            .then(function (response) {
                console.log(response);
                setShow(!show);
                toast.success(response.data.message, {position: toast.POSITION.BOTTOM_LEFT,autoClose:3000})
            })

     }
}


const validate = () => {

  let isValid = true;
  let error = {};

  if (!formInputs["username"]) {
    isValid = false;
    error["username"] = "Please enter user name.";
  }

  if (!formInputs["movie"]) {
    isValid = false;
    error["movie"] = "Please enter movie.";
  }

  if (!formInputs["tickets"]) {
    isValid = false;
    error["tickets"] = "Please enter tickets.";
  }
  if (!formInputs["total"]) {
    isValid = false;
    error["total"] = "Please enter total .";
  }
  
  setErrors(error);

  return isValid;
}
const validUserName=()=>{
  let error=""
  if (!formInputs["username"]) {  
      error = "Please enter username.";
  }

  else {
      if (formInputs["username"].length < 3) {
          error = "Please add at least 3 character.";
      }
  }
  setErrors(values => ({ ...values, username:error}))

}
const validMovieName=()=>{
  let error=""
  if (!formInputs["movie"]) {  
      error = "Please enter movie.";
  }

  else {
      if (formInputs["movie"].length < 3) {
          error = "Please add at least 3 character.";
      }
  }
  setErrors(values => ({ ...values, movie:error}))

}
const validTickets=()=>{
  let error=""
  if (!formInputs["tickets"]) {  
      error = "Please enter tickets.";
  }

  
  setErrors(values => ({ ...values, tickets:error}))

}
const validTotal=()=>{
  let error=""
  if (!formInputs["total"]) {  
      error = "Please enter total.";
  }

  
  setErrors(values => ({ ...values, total:error}))

}

    const COLOMUNS = [
        {
            Header: "ID",
            accessor: "id",
          },
      {
        Header: "Username",
        accessor: "username",
      },
      {
        Header: "Movie Name",
        accessor: "movie",
      },
      {
        Header: "Tickets",
        accessor: "tickets",
      },
      {
        Header: "Total",
        accessor: "total",
      },
      {
        Header: "Created",
        accessor: "createdAt",
      },
    ];
  
    useEffect(() => {
      const fetchTd = async () => {
        await axios
          .get(`http://localhost:8080/api/aorders`)
          .then((res) => {
            const ord = [...res.data];
            setData(ord);
          });
      };
      fetchTd();
    }, [show,effectrunner]);
  

    const updatedList = orders.map(item => 
      {
          
          return {...item, createdAt:dateFormat(item.createdAt,configData.DATE_FORMAT,true)}
         
      })
    
    const columns = useMemo(() => COLOMUNS, []);
    const data = useMemo(() => updatedList, [orders]);
    
    const {
      getTableProps,
      getTableBodyProps,
      headerGroups,
      page,
      nextPage,
      previousPage,
      canPreviousPage,
      canNextPage,
      pageOptions,
      state,
      setGlobalFilter,
      setPageSize,
      prepareRow,
    } = useTable(
      {
        columns,
        data,
        initialState: { pageIndex: 0 },
      },
      useGlobalFilter,
      usePagination
    );
  
    const { pageIndex, pageSize, globalFilter } = state;
  
    return (
      <>
      <title>{configData.TITLE.ORDERS}</title>
        <Container>
          <Row>
            <Card
              style={{ width: "13rem", marginLeft: "20px", marginTop: "20px" }}
            >
              <Card.Body style={{fontSize:"20px"}}>
                <b>Manage Orders</b>
              </Card.Body>
            </Card>
          </Row>
          <Row>
            <Col sm={3}></Col>
            <Col sm={5}>
              <input
                class="form-control"
                placeholder="Search Orders"
                value={globalFilter || ""}
               
                onChange={(e) => setGlobalFilter(e.target.value)}
              ></input>
            </Col>
            <Col>
            
            <Button variant="primary" className="justify-content-end"  style={{float:"right"}}><Link to="AdminMovies"   style={{  textDecoration: "none",color:"white"}}>Add New Booking</Link></Button>
           
            </Col>
          </Row>

{/* Modal for delete  */}


<Modal show={deletemodal.show} onHide={() =>setDeleteModal({ id: "", show: !deletemodal.show })}>
                       <Modal.Title>Confirm Delete</Modal.Title>
                        <Modal.Body>
                            <Row>
                                <Col>
                                    <p>Are you sure to delete order?</p>
                                </Col>
                            </Row>

                            <Row>
                                <Col sm={{ offset: 7, span: 2 }}>
                                    <Button variant="danger" onClick={() => handleDelete(deletemodal.id)}>Delete</Button>
                                </Col>
                                <Col sm={{ span: 3 }}>
                                    <Button variant="secondary" onClick={() => setDeleteModal({ id: "", show: !deletemodal.show })}>Cancel</Button>
                                </Col>
                            </Row>
                        </Modal.Body>
                    </Modal>



     {/* popupwindow for edit and delete orders */}
    
          <Modal show={show} onHide={handleClose}>
        <Modal.Header style={{backgroundColor:"#1266F1"}} >
          <Modal.Title className='modaltitle' >Edit Orders</Modal.Title>
        </Modal.Header>
        <Modal.Body className='modalform'>
          <Form >
            <Form.Group class="form-group required" controlId="formUser">
              <Form.Label class='control-label'>User Name</Form.Label>
              <Form.Control onBlur={validUserName}
                type="text"
                placeholder="UserName"
                value={formInputs.username}
                name="username"
                onChange={(e) => onValueChange(e)}
                autoFocus
              />{errors.username ? <div className="errors">{errors.username}</div> : null}
            </Form.Group>
            <Form.Group class="form-group required" controlId="formMovie">
              <Form.Label class='control-label'>Movie Name</Form.Label>
              <Form.Control onBlur={validMovieName}
                type="text"
                placeholder="Movie Name"
                value={formInputs.movie}
                name="movie"
                onChange={(e) => onValueChange(e)}
              />{errors.movie ? <div className="errors">{errors.movie}</div> : null}
            </Form.Group>
            <Form.Group class="form-group required" controlId="formTickets">
              <Form.Label class='control-label' >Tickets</Form.Label>
              <Form.Control onBlur={validTickets}
                type="number"
                placeholder="Number of Tickets"
                value={formInputs.tickets}
                name="tickets"
                onChange={(e) => onValueChange(e)}
              />{errors.tickets ? <div className="errors">{errors.tickets}</div> : null}
            </Form.Group>
            <Form.Group class="form-group required" controlId="formTotal">
              <Form.Label class='control-label' >Total</Form.Label>
              <Form.Control onBlur={validTotal}
                type="number"
                placeholder="Number of Total"
                value={formInputs.total}
                name="total"
                onChange={(e) => onValueChange(e)}
              />{errors.total ? <div className="errors">{errors.total}</div> : null}
            </Form.Group>
            
          </Form>
        </Modal.Body>
        <Modal.Footer style={{backgroundColor:"#1266F1"}}>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="warning" onClick={handleEdit}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>








      {Addshow&&<BookingPage show={Addshow}  handleClose={handleAddClose}/>}





      <div style={{overflowX:"auto"}}> 
          <Table
            bordered
            hover
            style={{ marginTop: "30px" }}
            {...getTableProps()}
          >
            <thead style={{ backgroundColor: "#1266F1", color: "white" }}>
              {headerGroups.map((headerGroup) => (
                <tr {...headerGroup.getHeaderGroupProps()}>
                  {headerGroup.headers.map((column) => (
                    <th {...column.getHeaderProps()}>
                      {column.render("Header")}
                    </th>
                  ))}
                  <th>Action</th>
                </tr>
              ))}
            </thead>
            <tbody
              {...getTableBodyProps()}
              style={{ backgroundColor: "rgb(212, 237, 245)" }}
            >
              {page.map((row) => {
                prepareRow(row);
                return (
                  <tr {...row.getRowProps()}>
                    {row.cells.map((cell) => 
                      (
                        <td {...cell.getCellProps()}>{cell.render("Cell")}</td>
                      )
                      )}
                    <td> <Button variant="warning" onClick={()=>editOrder(row.values)}>Edit</Button>{'      '}<Button variant="danger" onClick={() => deleteOrder(row.values.id)}>Delete</Button>  </td>
                    </tr>
                );
              })}
            </tbody>
          </Table>
          </div>
          <div>
            <Row>
              <Col sm={8}></Col>
              <Col>
                <Button
                  variant="primary"
                  onClick={() => previousPage()}
                  disabled={!canPreviousPage}
                >
                  Previous
                </Button>{"     "}
                <span>
                  Page{" "}
                  <strong>
                    {pageIndex + 1} of {pageOptions.length}
                  </strong>{" "}
                </span>
                <select
                  value={pageSize}
                  onChange={(e) => setPageSize(Number(e.target.value))}
                >
                  {[5, 10, 50].map((pageSize) => (
                    <option key={pageSize} value={pageSize}>
                      Show {pageSize}
                    </option>
                  ))}
                </select>{" "}
                <Button
                  variant="primary"
                  onClick={() => nextPage()}
                  disabled={!canNextPage}
                >
                  Next
                </Button>
              </Col>
            </Row>
          </div>
        </Container>
      </>
    );
  };
export default AdminManageOrders
