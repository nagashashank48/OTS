import React from "react";
import { useTable, usePagination, useGlobalFilter } from "react-table";
import { Table, Button, Row, Col, Container, Card ,Form} from "react-bootstrap";
import { useEffect, useMemo, useState } from "react";
import axios from "axios";
import { CSVLink } from "react-csv";
import configData from "../../../config.json";
import dateFormat from 'dateformat';



const AdminReports = () => {
  

  const [reportsData, setReportsData] = useState([]);
  const [forminputs, setFormInputs] = useState({});
  const [filterdates, setFilterDates] = useState({
    startdate: '',
    enddate: '',
  });
  const [errors, setErrors] = useState({});

  const [orders, setData] = useState([]);
  const COLOMUNS = [
    {
      Header: "ID",
      accessor: "id",
    },
    {
      Header: "User Name",
      accessor: "username",
    },
    {
      Header: "Movie",
      accessor: "movie",
    },
    {
      Header: "Total",
      accessor: "total",
    },
    {
      Header: "Created",
      accessor: "createdAt",
    },
  ];

  useEffect(() => {
    const fetchTd = async () => {
      await axios
      //https://jsonblob.com/api/jsonBlob/956128188216655872
        .get(`http://localhost:8080/api/aorders`)
        .then((res) => {
          const ord = [...res.data];
          
          const updatedList = ord.map(item => 
            {
                
                return {...item, createdAt:dateFormat(item.createdAt,configData.DATE_FORMAT,true)}
                
            })
            console.log(updatedList);
            setData(ord);
          setReportsData(updatedList);
        });
    };
    fetchTd();
  }, []);


  const validateStart = () => {
    let error = '';
    if (!forminputs['startdate'] && forminputs['enddate']) {
      error = 'Please enter Start-date';
    }
    if (!forminputs['startdate'] && !forminputs['enddate']) {
      setErrors({});
    }
    setErrors((values) => ({ ...values, startdate: error }));
  };

  const validateEnd = () => {
    let error = '';
    if (!forminputs['enddate'] && forminputs['startdate']) {
      error = 'Please enter End-date';
    }
    if (!forminputs['startdate'] && !forminputs['enddate']) {
      setErrors({});
    } 
    else if (forminputs['enddate'] && forminputs['startdate']) {
      let startdate = new Date(forminputs['startdate']);
      let enddate = new Date(forminputs['enddate']);
      if (startdate > enddate) {
        error = 'End-date should be greater than Start-date';
      }
    }
    setErrors((values) => ({ ...values, enddate: error }));
  };

  const validate = () => {
    validateStart();
    validateEnd();
    if (errors.startdate || errors.enddate) {
      return false;
    } else {
      return true;
    }
  };


  const handleSubmit = () => {
    if (validate()) {
      setFilterDates({ ...forminputs });
    }
    //console.log(forminputs);
    console.log(typeof forminputs.startdate);
    let stdate = new Date(forminputs.startdate);
    let endate = new Date(forminputs.enddate);
    console.log(orders);
    let newData = orders.filter((report) => {
      let date = new Date(report.createdAt);
      console.log(date);
      if (date >= stdate && date <= endate) {
        return report;
      }
    });
     //console.log(newData);
     const updatedList = newData.map(item => 
      {
          
          return {...item, createdAt:dateFormat(item.createdAt,configData.DATE_FORMAT,true)}
          
      })
      console.log(updatedList);
      

     
    setReportsData(updatedList);
  };

  const handleChange = (event) => {
    const name = event.target.name;
    const value = event.target.value;
    setFormInputs((values) => ({ ...values, [name]: value }));
  };


  


  //console.log(orders);
  const columns = useMemo(() => COLOMUNS, []);
  const data = useMemo(() => reportsData, [reportsData]);
  
  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    page,
    nextPage,
    previousPage,
    canPreviousPage,
    canNextPage,
    pageOptions,
    state,
    setPageSize,
    prepareRow,
  } = useTable(
    {
      columns,
      data,
      initialState: { pageIndex: 0 },
    },
    useGlobalFilter,
    usePagination
  );

  const { pageIndex, pageSize } = state;
 
  const csvLink = {
    data,
    filename: "Online Ticket Booking from "+filterdates.startdate+" to "+filterdates.enddate+".csv",
     };
  return (
    <div>
      <title>{configData.TITLE.REPORTS}</title>
    
      <Container>
      
      <Row>
          <Card
            style={{ width: "13rem", marginLeft: "20px", marginTop: "20px" }}
          >
            <Card.Body style={{fontSize:"20px"}}>
              <b>Reports</b>
            </Card.Body>
          </Card>
        </Row>
      
      <Row className="mt-5">
            
        <Col sm={4}>
        <Form.Group controlId="reportstartdate">
              <Row >
              <Col sm={3}>
                <Form.Label >
                  <b>StartDate</b>
                </Form.Label>
              </Col>
              <Col >
                <Form.Control
                  
                  onBlur={validateStart}
                  onChange={handleChange}
                  name="startdate"
                  type="date"
                  placeholder="Start Date"
                />

                <Col className="text-danger text-center" >
                  {errors.startdate}
                </Col>
              
              </Col>
              </Row>
            </Form.Group>
       
        </Col>
      
        <Col sm={4} >
        <Form.Group controlId="reportenddate">
              <Row>
              <Col sm={3}>
                <Form.Label >
                  <b>EndDate</b>
                </Form.Label>
              </Col>
              <Col >
                <Form.Control
                  onBlur={validateEnd}
                  onChange={handleChange}
                  name="enddate"
                  type="date"
                  placeholder="End Date"
                />

                <Col className="text-danger text-center" >
                  {errors.enddate}
                </Col>
              </Col>
              </Row>
            </Form.Group>
        </Col>
        <Col sm={2}>
        
      
           <Button  variant="success" onClick={handleSubmit}>
              Submit
            </Button>
         
        </Col>
        <Col sm={2}> 
        <CSVLink {...csvLink}  style={{float:"right"}}>
          <Button variant="warning" className="ml-3 mt-1">
            Export as csv
          </Button></CSVLink>
          </Col>
         
      </Row>
    
<div>
<div className="tab">
    
     


  
<Table
          bordered
          hover
          style={{ marginTop: "30px" }}
          {...getTableProps()}
        >
          <thead style={{ backgroundColor: "#1266F1", color: "white" }}>
            {headerGroups.map((headerGroup) => (
              <tr {...headerGroup.getHeaderGroupProps()}>
                {headerGroup.headers.map((column) => (
                  <th {...column.getHeaderProps()}>
                    {column.render("Header")}
                  </th>
                ))}
              </tr>
            ))}
          </thead>
          <tbody
            {...getTableBodyProps()}
            style={{ backgroundColor: "rgb(212, 237, 245)" }}
          >
            {page.map((row) => {
              prepareRow(row);
              return (
                <tr {...row.getRowProps()}>
                  {row.cells.map((cell) => {
                    return (
                      <td {...cell.getCellProps()}>{cell.render("Cell")}</td>
                    );
                  })}
                </tr>
              );
            })}
          </tbody>
        </Table>
        <div>
          <Row>
            <Col sm={8}></Col>
            <Col>
              <Button
                variant="primary"
                onClick={() => previousPage()}
                disabled={!canPreviousPage}
              >
                Previous
              </Button>{" "}
              <span>
                Page{" "}
                <strong>
                  {pageIndex + 1} of {pageOptions.length}
                </strong>{" "}
              </span>
              <select
                value={pageSize}
                onChange={(e) => setPageSize(Number(e.target.value))}
              >
                {[5, 10, 50].map((pageSize) => (
                  <option key={pageSize} value={pageSize}>
                    Show {pageSize}
                  </option>
                ))}
              </select>{" "}
              <Button
                variant="primary"
                onClick={() => nextPage()}
                disabled={!canNextPage}
              >
                Next
              </Button>
            </Col>
          </Row>
        </div>

        </div>
    </div>
    </Container>
  </div> 
  )
}

export default AdminReports
