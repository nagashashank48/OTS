import React, { useEffect, useState } from "react";
import {
  Col,
  Row,
  Card,
  Container,
  Table,
  Button,
} from "react-bootstrap";
import {  Link } from "react-router-dom";
import axios from "axios";
import dateFormat from 'dateformat';

import configData from "../../config.json";

const AdminDashboardP = () => {
  const [recentScreen, setrecentScreen] = useState([10]);
  const [recentOrder, setrecentOrder] = useState([9]);
  const [recentReport, setrecentReport] = useState([8]);
  const [openScreen, setOpenScreen] = useState(2);
  
  const [recent, setrecent] = useState([3]);
  const [open, setOpen] = useState(2);
 

  const step = async () => {
    const current = await axios.get(`http://localhost:8080/api/users`);
    setrecent(current.data);
   
    console.log(current);
    
  };

  const stepScreen = async () => {
    const screens = await axios.get(`http://localhost:8080/api/screens`);
    setrecentScreen(screens.data);
    
  };
  const stepOrder = async () => {
    const orders = await axios.get( "http://localhost:8080/api/aorders");
    setrecentOrder(orders.data);
   
  };
  const stepReport = async () => {
    const reports = await axios.get(`http://localhost:8080/api/aorders`);
    setrecentReport(reports.data);
  };

  useEffect(() => {
    step();
    stepScreen();
    stepOrder();
    stepReport();
  }, []);

  
  return (
    <div>
    <title>{configData.TITLE.APP_TITLE}</title>
      <Container>
        <br></br>
        <Row style={{alignItems:"center"}}>
          <Col sm={3}>
           
              <Link
                to="/manage-users"
                style={{ color: "white", textDecoration: "none" }}
              >
                <Card key="1" style={{ width: "13rem", backgroundColor: "#ff0000" }}>
                  <Card.Body>
                    <Card.Title>Total Users</Card.Title>
                    <i class="bi bi-people-fill" style={{ fontSize: 50 }}></i>
                    <Card.Text style={{ fontSize: 30 }}>
                      {recent.length}
                    </Card.Text>
                  </Card.Body>
                </Card>
              </Link>
           
          </Col>
          <Col sm={3}>
           
              <Link
                to="/manage-screens"
                style={{ color: "white", textDecoration: "none" }}
              >
                <Card key="2" style={{ width: "13rem", backgroundColor: "slateblue" }}>
                  <Card.Body>
                    <Card.Title>Total Screens</Card.Title>
                    <i class="bi bi-film" style={{ fontSize: 50 }}></i>
                    <Card.Text style={{ fontSize: 30 }}>
                      {recentScreen.length}
                    </Card.Text>
                  </Card.Body>
                </Card>
              </Link>
           
          </Col>
          <Col sm={3}>
          
              <Link
                to="/AdminManageOrders"
                style={{ color: "white", textDecoration: "none" }}
              >
                <Card key="3" style={{ width: "13rem", backgroundColor: "#ffa500" }}>
                  <Card.Body>
                    <Card.Title >Total Orders</Card.Title>
                    <i
                      class="bi bi-camera-reels-fill"
                      style={{ fontSize: 50 }}
                    ></i>
                    <Card.Text style={{ fontSize: 30 }}>{recentOrder.length}</Card.Text>
                  </Card.Body>
                </Card>
              </Link>
           
          </Col>
          <Col sm={3}>
         
              <Link
                to="/AdminReports"
                style={{ color: "white", textDecoration: "none" }}
              >
                <Card key="4" style={{ width: "13rem", backgroundColor: "#3cb371" }}>
                  <Card.Body>
                    <Card.Title>Total Reports</Card.Title>

                    <i class="bi bi-ticket-fill" style={{ fontSize: 50 }}></i>
                    <Card.Text style={{ fontSize: 30 }}>{recentReport.length}</Card.Text>
                  </Card.Body>
                </Card>
              </Link>
            
          </Col>
        </Row>

        <Row style={{ marginTop: "40px" }}>
          <Col sm={4}>
            <h5>Recent Users</h5>
          </Col>
          <Col md={{ span: 2, offset: 6 }} sm={{ span: 3, offset: 5 }}>
            <Button
              
              style={{ width: "100%" }}
              variant="success"
            ><Link
            to="/manage-users"
            style={{  textDecoration: "none",color:"white" }}
          >
             View All </Link>
            </Button>
          </Col>
        </Row>
        <br></br>
        <Row>
          <Col>
          <div style={{overflowX:"auto"}}>
            <Table bordered>
              <thead style={{ backgroundColor: "#1266F1", color: "white" }}>
                <tr>
                  <th>Id</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Gender</th>
                  <th>Created</th>
                </tr>
              </thead>
              <tbody style={{ backgroundColor: "rgb(212, 237, 245)" }}>
                {recent.slice(0, open).map((json) => (
                  <tr key={json.id}>
                    <td>{json.id}</td>
                    <td>{json.name}</td>
                    <td>{json.email}</td>
                    <td>{json.gender}</td>
                    <td> {dateFormat(json.createdAt,configData.DATE_FORMAT,true)}</td>
                  </tr>
                ))}
              </tbody>
            </Table>
            </div>
          </Col>
        </Row>
        <Row style={{ marginTop: "40px" }}>
          <Col sm={4}>
            <h5>Screens</h5>
          </Col>
          <Col md={{ span: 2, offset: 6 }} sm={{ span: 3, offset: 5 }}>
            <Button
              
              style={{ width: "100%" }}
              variant="success"
            ><Link
            to="/manage-screens"
            style={{  textDecoration: "none",color:"white"}}
          >
             View All </Link>
            </Button>
          </Col>
        </Row>
        <br></br>
        <Row>
          <Col>
          <div style={{overflowX:"auto"}}>
            <Table bordered>
              <thead style={{ backgroundColor: "#1266F1", color: "white" }}>
                <tr>
                  <th>Id</th>
                  <th>Screen Name</th>
                  <th>Total Seats</th>
                  <th>Created</th>
                </tr>
              </thead>
              <tbody style={{ backgroundColor: "rgb(212, 237, 245)" }}>
                {recentScreen.slice(0, openScreen).map((dat) => (
                  <tr key={dat.id}>
                    <td>{dat.id}</td>
                    <td>{dat.screenname}</td>
                    <td>{dat.totalseats}</td>
                    <td>{dateFormat(dat.createdAt,configData.DATE_FORMAT,true)}</td> 
                  </tr>
                ))}
              </tbody>
            </Table>
            </div>
          </Col>
        </Row>
      </Container>
    </div>
  );
};

export default AdminDashboardP;
