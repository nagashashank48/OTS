import React from 'react'
import { Navbar,Nav,NavDropdown} from "react-bootstrap";
import {NavLink,Outlet,Link} from 'react-router-dom'
import { useSelector ,useDispatch } from 'react-redux'
import "./AdminDashboard.css"
import configData from '../../config'


const AdminDashboard = () => {
   
  



  const dispatch=useDispatch();
  const logout=()=>{
     dispatch({type:"SETAUTHTOKEN", data:{}})
  }
  const selectauthToken = (rootstate) => rootstate.authToken
   const authToken = useSelector(selectauthToken)
  console.log(authToken);
  return (
    <div>
      
      <Navbar collapseOnSelect expand="lg" bg="primary" variant="dark">
        
          
          <Navbar.Brand style={{fontSize:"30px"}}><Link to="/"  style={{textDecoration:"none",color:"white"}} >{configData.TITLE.APP_TITLE}</Link></Navbar.Brand>
         
         
              <Navbar.Toggle/>
            <Navbar.Collapse id="navbarScroll">
            <Nav className="me-auto">
              
            

            <Nav.Link >
            <NavLink className="adashlink" style={({isActive})=>{return{backgroundColor:(isActive?'gray':'#1266F1')}}} to="/manage-users">
              <b>Users</b>
                </NavLink>
              </Nav.Link>
             
             
              <Nav.Link>
                <NavLink className="adashlink" style={({isActive})=>{return{backgroundColor:(isActive?'gray':'#1266F1')}}} to="/manage-screens">
               <b> Screens</b>
                </NavLink>
              </Nav.Link>

              <Nav.Link>
              <NavLink  className="adashlink" style={({isActive})=>{return{backgroundColor:(isActive?'gray':'#1266F1')}}}
                  to="AdminManageOrders" >
                  <b>Orders</b>
                </NavLink>
              </Nav.Link>

              <Nav.Link>
              <NavLink  className="adashlink" style={({isActive})=>{return{backgroundColor:(isActive?'gray':'#1266F1')}}}
                  to="/AdminReports"
                >
                  <b>Reports</b>
                </NavLink>
              </Nav.Link>

              
             
            </Nav>
            </Navbar.Collapse>
            
        
          <Navbar.Toggle />
          <Navbar.Collapse className="justify-content-end">
          <Nav>
          <Navbar.Text style={{color:'white',alignContent:"center"}}>
             <b> Signed in as:</b>
            </Navbar.Text>
            <NavDropdown
              id="nav-dropdown-dark-example"
              title={authToken.email}
              menuVariant="light"
              align="end"  
              style={{color:'red'}} 
            >
              <NavDropdown.Item ><Link to="Changepassword">Change Password</Link> </NavDropdown.Item>
              <NavDropdown.Divider />
              <NavDropdown.Item as="button" onClick={logout}><Link to="/">Logout</Link></NavDropdown.Item>
            </NavDropdown>
          </Nav>
           
          </Navbar.Collapse>
          
         
        
      </Navbar>
      



      <Outlet/>
    </div>
  );
}

export default AdminDashboard
