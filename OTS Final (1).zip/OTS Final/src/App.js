import React from "react";
import Register from "./login/register";
import {BrowserRouter,Routes,Route} from "react-router-dom"
import Mdashboard from "./Mdashboard"
import Forgot from "./login/forgot"
import UserOrders from "./login/user/UserOrders"
import AdminManageOrders from "./login/admin/AdminManageOrders"
import AdminManageUsers from "./login/admin/AdminManageUsers"
import AdminManageScreens from "./login/admin/AdminManageScreens"
import AdminReports from "./login/admin/AdminReports/AdminReports"
import AdminMovies from "./login/admin/AdminMovies";
import { useSelector } from 'react-redux';
import Spinner from './Spinner/Spinner'
import Changepassword from './login/Changepassword'



function App() {
  const selectauthToken = (rootstate) => rootstate.authToken
  const authToken = useSelector(selectauthToken)
   
    const AdminDashboardPag = React.lazy(() => {
      return new Promise(resolve => {
        setTimeout(() => resolve(import("./login/admin/AdminDashboardP")), 2000);
      });
    });
    const UserMovies = React.lazy(() => {
      return new Promise(resolve => {
        setTimeout(() => resolve(import("./login/user/UserMovies")), 2000);
      });
    });
  
  return (


  
    <BrowserRouter>
    <Routes>
    <Route path="/register" element={<Register/>}> </Route>
    <Route path="/forgot" element={<Forgot/>}> </Route>
    <Route path="/" element={<Mdashboard/>}> 
    <Route path="/UserOrders" element={<UserOrders/>}/>
    { (authToken.role==="ADMIN")?<Route index element={<React.Suspense fallback={<h1><center>...Loading<Spinner/></center></h1>}>
    <AdminDashboardPag/>
              </React.Suspense>}/>:<Route index element={<React.Suspense fallback={<h1><center>...Loading<Spinner/></center></h1>}>
    <UserMovies/>
              </React.Suspense>}/>  }
    <Route path="/manage-users" element={<AdminManageUsers/> }/>
    <Route path="/manage-screens" element={<AdminManageScreens/> }/>
    <Route path="/AdminReports" element={< AdminReports/> }/>
    <Route path="/AdminManageOrders/AdminMovies" element={< AdminMovies/> }/>
    <Route path="/Changepassword" element={< Changepassword/> }/>
    <Route path="/AdminManageOrders" element={<AdminManageOrders/>}>
    
    </Route>
    
     </Route>
   


    </Routes>
    </BrowserRouter>
  );
}

export default App;


