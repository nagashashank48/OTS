module.exports = app => {
    const usermovie = require("../controllers/usermovie.controller.js");
    var router = require("express").Router();
    router.get("/", usermovie.findAll);
    app.use('/api/usermovies', router);
  };