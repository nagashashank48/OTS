module.exports = app => {
    const aorder = require("../controllers/aorders.controller.js");
    var router = require("express").Router();
    // Create a new user
    router.post("/", aorder.create);
    // Retrieve all users
    router.get("/", aorder.findAll);
     
    
    // Update a user with id
    router.put("/:id", aorder.update);
    // Delete a user with id
    router.delete("/:id",aorder.delete);
  
    router.get("/:id", aorder.findOne);
    app.use('/api/aorders', router);
  };