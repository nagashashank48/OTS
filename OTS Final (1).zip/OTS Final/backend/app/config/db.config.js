module.exports = {
    url: "mongodb+srv://shashank:shashank8@ots.ge9b6.mongodb.net/ots?retryWrites=true&w=majority"
  };