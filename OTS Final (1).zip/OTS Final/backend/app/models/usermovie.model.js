module.exports = mongoose => {
    var schema = mongoose.Schema(
      {
        screen:String,
        movie:String,
        price:Number,
        img:String,
      },
      { timestamps: true }
    );
    schema.method("toJSON", function() {
      const { __v, _id, ...object } = this.toObject();
      object.id = _id;
      return object;
    });
    const usermovie = mongoose.model("usermovie", schema);
    return usermovie;
  };