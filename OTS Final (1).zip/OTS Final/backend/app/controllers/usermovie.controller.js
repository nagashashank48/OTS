const db = require("../models");
const usermovie= db.usermovies;
exports.findAll = async (req, res) => {
    await usermovie.find()
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving usermovie."
      });
    });
  };