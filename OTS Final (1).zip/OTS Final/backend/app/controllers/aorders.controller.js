const db = require("../models");
const Aorder = db.aorders;
// Create and Save a new user
exports.create = (req, res) => {
  if (!req.body.username) {
    res.status(400).send({ message: "Content can not be empty!" });
    return;
  }
  // Create a user
  const aorder = new Aorder({
    username: req.body.username,
    movie: req.body.movie,
    tickets: req.body.tickets,
    total: req.body.total,
   
   
  });
  // Save user in the database
  aorder
    .save(aorder)
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while creating the order."
      });
    });
};
exports.findAll = async (req, res) => {
  await Aorder.find()
  .then(data => {
    res.send(data);
  })
  .catch(err => {
    res.status(500).send({
      message:
        err.message || "Some error occurred while retrieving orders."
    });
  });
};

exports.findOne = (req, res) => {
    const id = req.params.id;
    Aorder.findById(id)
      .then(data => {
        if (!data)
          res.status(404).send({ message: "Not found order with id " + id });
        else res.send(data);
      })
      .catch(err => {
        res
          .status(500)
          .send({ message: "Error retrieving order with id=" + id });
      });
  };
// Update a user by the id in the request
exports.update = (req, res) => {
  if (!req.body) {
    return res.status(400).send({
      message: "Data to update can not be empty!"
    });
  }
  const id = req.params.id;
  Aorder.findByIdAndUpdate(id, req.body, { useFindAndModify: false })
    .then(data => {
      if (!data) {
        res.status(404).send({
          message: `Cannot update order with id=${id}. Maybe user  was not found!`
        });
      } else res.send({ message: "Order was updated successfully." });
    })
    .catch(err => {
      res.status(500).send({
        message: "Error updating order with id=" + id
      });
    });
};
// Delete a user with the specified id in the request
exports.delete = (req, res) => {
    const id = req.params.id;
    Aorder.findByIdAndRemove(id)
      .then(data => {
        if (!data) {
          res.status(404).send({
            message: `Cannot delete order with id=${id}. Maybe order was not found!`
          });
        } else {
          res.send({
            message: "order was deleted successfully!"
          });
        }
      })
      .catch(err => {
        res.status(500).send({
          message: "Could not delete order with id=" + id
        });
      });
  };
// Delete all Tutorials from the database.
exports.deleteAll = (req, res) => {
  
};

