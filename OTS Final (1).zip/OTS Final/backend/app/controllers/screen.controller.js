const db = require("../models");
const Asc = db.screens;
// Create and Save a new user
exports.create = (req, res) => {
  if (!req.body.screenname) {
    res.status(400).send({ message: "Content can not be empty!" });
    return;
  }
  // Create a user
  const screen = new Asc({
    
    screenname:req.body.screenname,
   
    totalseats:req.body.totalseats
    
   
  });
  // Save user in the database
  screen
    .save(screen)
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while creating the screen."
      });
    });
};

exports.findOne = (req, res) => {
  const id = req.params.id;
  Asc.findById(id)
    .then(data => {
      if (!data)
        res.status(404).send({ message: "Not found screen with id " + id });
      else res.send(data);
    })
    .catch(err => {
      res
        .status(500)
        .send({ message: "Error retrieving screen with id=" + id });
    });
};
exports.findAll = async (req, res) => {
  await Asc.find()
  .then(data => {
    res.send(data);
  })
  .catch(err => {
    res.status(500).send({
      message:
        err.message || "Some error occurred while retrieving screen."
    });
  });
};
// Find a single auser with an id
exports.findOne = (req, res) => {
  
};
// Update a user by the id in the request
exports.update = (req, res) => {
  if (!req.body) {
    return res.status(400).send({
      message: "Data to update can not be empty!"
    });
  }
  const id = req.params.id;
  Asc.findByIdAndUpdate(id, req.body, { useFindAndModify: false })
    .then(data => {
      if (!data) {
        res.status(404).send({
          message: `Cannot update screen with id=${id}. Maybe screen  was not found!`
        });
      } else res.send({ message: "Screen  was updated successfully." });
    })
    .catch(err => {
      res.status(500).send({
        message: "Error updating screen  with id=" + id
      });
    });
};
// Delete a user with the specified id in the request
exports.delete = (req, res) => {
    const id = req.params.id;
    Asc.findByIdAndRemove(id)
      .then(data => {
        if (!data) {
          res.status(404).send({
            message: `Cannot delete screen with id=${id}. Maybe User was not found!`
          });
        } else {
          res.send({
            message: "Screen was deleted successfully!"
          });
        }
      })
      .catch(err => {
        res.status(500).send({
          message: "Could not delete screen with id=" + id
        });
      });
  };
// Delete all Tutorials from the database.
exports.deleteAll = (req, res) => {
  
};
