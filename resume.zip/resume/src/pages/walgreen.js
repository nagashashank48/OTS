import React from 'react'
import Navbar from '../components/navbar'
import {Row,Col} from 'react-bootstrap'
const booking = () => {
  return (
    <div>
        <Navbar></Navbar>
      <div>
         
         <div style={{fontSize:'25px',fontWeight:'bold',paddingTop:'40px'}}> walgreen</div><br></br>
          <Row><Col sm='2'><b>Technologies Used     :</b></Col><Col>HTML , CSS , BOOTSTRAP ,<b> REACT , NODE JS , MONGODB</b></Col> </Row><br></br>
          <Row><Col sm='2'><b>Description   :</b></Col> <Col>the app contains two login roles.1)admin 2)user .<br></br>
            in admin we can see the total of users,users orders,total screens,reports.<br></br>
            we can able to book tickets from admin also.<br></br>
             in user,the user can book the tickets for any screen in list and the he also see his orders which  he has booked previously</Col> </Row><b></b>
            <Row><Col sm='2'> <b>Source code    :</b></Col><Col>www.aaaaa.com</Col></Row>
   </div> </div>
  )
}

export default booking
