import React, { useState } from 'react';
import {Carousel} from 'react-bootstrap';
import {NavLink} from 'react-router-dom'
import Navbar from '../components/navbar'

const Projects = ()=> {
  const [index, setIndex] = useState(0);

  const handleSelect = (selectedIndex, e) => {
    setIndex(selectedIndex);
  };

  return (
     <div><Navbar></Navbar>
    <Carousel  activeIndex={index} onSelect={handleSelect}>

      <Carousel.Item >
        <img className='carousel'
        //   className="d-block w-100"
          src="https://th.bing.com/th/id/OIP.Uk5vTQtqREeGUPimpg8iIAHaFj?pid=ImgDet&rs=1"
          alt="First slide" 
        />
        <Carousel.Caption>
         <NavLink to="/booking" style={{textDecoration:"none",color:"white"}}> <h3>MOVIE TICKET BOOKING</h3></NavLink>
          <p>Book Your Movie Tickets Here..</p>

        </Carousel.Caption>
      </Carousel.Item>
      
      <Carousel.Item>
        <img
        //   className="d-block w-100"
          src="https://th.bing.com/th/id/OIP.Uk5vTQtqREeGUPimpg8iIAHaFj?pid=ImgDet&rs=1"
          alt="Second slide" height="600px" width='1150px' style={{paddingLeft:'180px',paddingTop:"50px"}}
        />

        <Carousel.Caption>
        <NavLink to="/loan" style={{textDecoration:"none",color:"white"}}> <h3>LOAN APP</h3></NavLink>
          <p>Know Details of your loan</p>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <img
        //   className="d-block w-100"
          src="https://th.bing.com/th/id/OIP.Uk5vTQtqREeGUPimpg8iIAHaFj?pid=ImgDet&rs=1"
          alt="Third slide" height="600px" width='1150px' style={{paddingLeft:'180px',paddingTop:"50px"}}
        />

        <Carousel.Caption>
        <NavLink to="/walgreen" style={{textDecoration:"none",color:"white"}}> <h3>API CALLS</h3></NavLink>
          <p>Made api calls </p>
        </Carousel.Caption>
      </Carousel.Item>
    </Carousel>
    </div>
  );
}

export default Projects