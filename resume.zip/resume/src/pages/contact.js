import React from 'react'
import Navbar from '../components/navbar'

const contact = () => {
  return (
    <div>
                <Navbar></Navbar>
                <div className='contact' style={{paddingTop:'150px',paddingLeft:'200px'}}>
              <div> <img src="https://th.bing.com/th/id/OIP.Y-88DaxYkV5uMFvUXPc2jwHaHa?pid=ImgDet&rs=1" alt="" height="35px" width='35px' />   <a href="https://www.facebook.com">facebook</a></div> <br></br>
              <div> <img src="https://th.bing.com/th/id/OIP.d0UnJ-mM0W32fXirQeDU3AHaHa?pid=ImgDet&w=207&h=207&c=7" alt="" height="35px" width='35px' />nagashashank48@gmail.com</div> <br></br>
              <div> <img src="https://th.bing.com/th/id/OIP.IfuhJTGsN34WQqAZIdufvQHaHa?w=191&h=191&c=7&r=0&o=5&pid=1.7" alt="" height="35px" width='35px' /> <a href="https://www.linkedin.com">linkedin</a></div> <br></br>
              <div> <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e7/Instagram_logo_2016.svg/1200px-Instagram_logo_2016.svg.png" alt="" height="35px" width='35px' /> <a href="https://www.instagram.com">instagram</a></div> 
              </div>
    </div>
  )
}

export default contact
