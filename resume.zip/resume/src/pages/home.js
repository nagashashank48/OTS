import React from 'react'
import "../components/navbar.css"
import Homenav from "../components/homenav"
const home = () => {
  return (
    <div>
     <Homenav></Homenav>
      <div className='name'>Gudipati Naga Shashank</div>
      <div style={{    paddingLeft: '800px',color:'#3300cc'}}>-Mern Stack Developer</div>

      <div className='about'>ABOUT</div>
      <div>i am mern stack developer with an year experience in Cognizant</div>
       
    </div>
  )
}

export default home
