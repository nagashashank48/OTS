import React from 'react'
import Navbar from '../components/navbar'
import {Row,Col } from "react-bootstrap"
const loan = () => {
  return (
    <div>    
<Navbar></Navbar>
<div>
         
         <div style={{fontSize:'25px',fontWeight:'bold',paddingTop:'40px'}}> LOAN-APP</div><br></br>
          <Row><Col sm='2'><b>Technologies Used     :</b></Col><Col>HTML , CSS , BOOTSTRAP ,<b> REACT , NODE JS , MONGODB , JEST</b></Col> </Row><br></br>
          <Row><Col sm='2'><b>Description   :</b></Col> <Col>These app is used to edit the details of profile and accountant information.<br></br>
          we can see the all loans of the user and we can edit,delete the use loan.the status of loan can be edited also<br></br>
          in the end the unit testing is developed to the app.</Col> </Row><b></b>
            <Row><Col sm='2'> <b>Source code    :</b></Col><Col>www.aaaaa.com</Col></Row>
   </div>
    </div>
  )
}

export default loan
