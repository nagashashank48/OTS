import React from 'react'
import Navbar from '../components/navbar'

const experience = () => {
  return (

    <div>
          <Navbar></Navbar>
          <div style={{paddingTop:'70px',paddingLeft:'70px'}}>
         <div style={{fontSize:'25px',color:'#0000cc'}}> <b>Cognizant Technology Solutions</b></div><br></br>
         <div> Role : <b style={{fontSize:'20px'}}> Programmer Analyst  </b></div><br></br>
         <div> Domain : <b  style={{fontSize:'20px'}}> MERN Stack Development</b></div> <br></br>
         <div> Duration :<b  style={{fontSize:'20px'}}> Nov 2021 – Present</b></div><br></br>
         </div>
    </div>
  )
}

export default experience
