import React from 'react'
import {Row,Col} from 'react-bootstrap'
import Navbar from '../components/navbar'
import "../components/navbar.css"
const skills = () => {
  return (
    <div><Navbar></Navbar>

      <Row>
        <Col style={{textAlign:"center",marginTop:"150px",borderRight:"2px solid"}}>
      <b style={{fontSize:'30px',borderBottom:'1px solid',color:'red'}}>Technical Skills</b> <br></br>
      <div className='skill'>HTML</div>
      <div className='skill'>CSS</div>
      <div className='skill'>JAVA SCRIPT</div>

     <div className='skill'> REACT JS</div>
     <div className='skill'>NODE JS</div>
     <div className='skill'> MONGO DB</div>
      </Col>
      <Col style={{marginTop:"150px",textAlign:"center"}}>
     <b style={{fontSize:'30px',borderBottom:'1px solid',color:'red'}}> Non Technical Skills</b><br></br>
     <div className='skill'>COMUNICATION</div>
     <div className='skill'>LEADERSHIP</div>
     <div className='skill'>ATTENTION TO DETAIL</div>


      </Col>
      </Row>
    </div>
  )
}

export default skills
