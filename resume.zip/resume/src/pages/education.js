import React from 'react'
import {Card,Row,Col} from 'react-bootstrap'
import Navbar from '../components/navbar'
import "../components/navbar.css"

const education = () => {
  return (
    <div>
                <Navbar></Navbar>

       
        <Row>
            <Col>
       <Card border="success"  style={{ width: "35rem", marginLeft: "15px", marginTop: "20px" }} >
           <Card.Header style={{textAlign:"center",fontWeight:'bold',backgroundColor:"#33cc33",fontSize:'20px'}}>Graduation</Card.Header>
            <Card.Body style={{fontSize:"18px",backgroundColor:"#66ffff"}}>
              University : <b>JNTUH</b><br></br>
              College : <b>Sreenidhi Institute Of Science And Technology</b><br></br>
              Passed Out : <b>2021</b><br></br>
              CGPA : <b>8.18</b>          
        </Card.Body>
          </Card>
          </Col>
         <Col className='icon'>  <span ><i class="bi bi-arrow-90deg-left" style={{fontSize:"100px"}}></i></span></Col>

          </Row>

<Row>
  <Col >

          <div className='card2'>
          <Card border="success"    >
           <Card.Header style={{textAlign:"center",fontWeight:'bold',backgroundColor:"#33cc33",fontSize:'20px'}} >Intermediate</Card.Header>
            <Card.Body style={{fontSize:"18px",backgroundColor:"#66ffff"}}>
              University : <b>BIETS</b><br></br>
              College : <b>Narayana Junior College</b><br></br>
              Passed Out : <b>2017</b><br></br>
              CGPA : <b>95.4%</b>
            </Card.Body>
          </Card>
           </div>
          </Col>

          <Col className='icon'> <span ><i   className="bi bi-arrow-90deg-left" style={{fontSize:"100px"}}></i></span></Col>
          </Row>
      <div className='card3'>
          <Card border="success"  >
           <Card.Header style={{textAlign:"center",fontWeight:'bold',backgroundColor:"#33cc33",fontSize:'20px'}}>Matriculation</Card.Header>
            <Card.Body style={{fontSize:"18px",backgroundColor:"#66ffff"}}>
              University : <b>SSC</b><br></br>
              College : <b>Kakatiya Techno School	</b><br></br>
              Passed Out : <b>2015</b><br></br>
              CGPA : <b>9.0</b>
            </Card.Body>
          </Card>
        </div>
    </div>
  )
}

export default education
