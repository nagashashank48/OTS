import {BrowserRouter,Routes,Route} from 'react-router-dom'
import Home from './pages/home'
import Education from './pages/education'
import Experience from './pages/experience'
import Skills from './pages/skills'
import Projects from './pages/Projects'
import Contact from './pages/contact'
import Booking from './pages/booking'
import Loan from './pages/loan'
import Walgreen from './pages/walgreen'
function App() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home/>} />
          <Route path="/home" element={<Home/>} />
          <Route path="/education" element={<Education/>} />
          <Route path="/experience" element={<Experience/>} />
          <Route path="/skills" element={<Skills/>} />
          <Route path="/projects" element={<Projects/>} />
          <Route path="/contact" element={<Contact/>} />
          <Route path="/booking" element={<Booking/>} />
          <Route path="/loan" element={<Loan/>} />
          <Route path="/walgreen" element={<Walgreen/>} />


        </Routes>
      </BrowserRouter>
    </>

  );
}

export default App;
