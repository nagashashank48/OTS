import React from 'react'
import { Navbar,Nav} from "react-bootstrap";
import {NavLink} from 'react-router-dom'
import "../components/navbar.css"


const navbar = () => {
   
  
  


 
  return (
    <div>
      
      <Navbar collapseOnSelect expand="lg"   className='navbar'>
        
          
          
         <Navbar.Toggle/>
            <Navbar.Collapse id="navbarScroll">
            <Nav className="me-auto"  >
              

            <NavLink className="adashlink"  activeClassName="active" to="/home"  >              HOME                </NavLink>
             
             <NavLink  className="adashlink"  activeClassName="active" to="/experience"  > EXPERIENCE  </NavLink>

              <NavLink  className="adashlink" activeClassName="active"  to="/education">EDUCATION  </NavLink>

                <NavLink  className="adashlink" activeClassName="active" to="/skills" >     SKILLS</NavLink>

                <NavLink  className="adashlink" activeClassName="active" to="/projects" >        PROJECTS              </NavLink>

                <NavLink  className="adashlink" activeClassName="active" to="/contact" >                  CONTACT             </NavLink>

              
             
            </Nav>
            </Navbar.Collapse>
            
        
        
         
        
      </Navbar>
      



      
    </div>
  );
}

export default navbar