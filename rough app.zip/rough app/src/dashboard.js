
import React,{useEffect,useState} from 'react' 
import { Table,Navbar,Button,Row,Col,Form,Modal } from 'react-bootstrap'
import axios from 'axios'



function Dashboard() {
  const [data, setData] = useState([]);
  const [inputs, setInputs] = useState({});
  const [count, setCount] = useState([{total:"",remaining:""}]);
  const [errors, setErrors] = useState({});
  const handleClose = () => setShow(false);
  const [show, setShow] = useState(false);
  // const [editdata,setEditdata]=useState({});
  const [formInputs, setformInputs] = useState({ name: "",id:"",status:""});
  const [orders, setOrder] = useState([]);
  const [deletemodal, setDeleteModal] = useState({ id: "", name: "", show: false })
  useEffect(() => {
   
      axios
      //https://jsonblob.com/api/jsonBlob/956128188216655872
        .get(`http://localhost:8080/api/order`)
        .then((res) => {
          const ord = [...res.data];
          
        
            
           setData(ord)
        
         
        });
        axios
        //https://jsonblob.com/api/jsonBlob/956128188216655872
          .get(`http://localhost:8080/api/count`)
          .then((res) => {
            const ord = [...res.data];
            
          setCount(ord)
              
             
            
           
          });

  }, []);
  const deleteScreen = (id, name) => {
    setDeleteModal({ id: id, name: name, show: !deletemodal.show })
}
const handleDelete = (id,name) => {

  
  axios.delete(`http://localhost:8080/api/order/${id}`)
  .then(res => {
      console.log(res);
      console.log(res.data);
  
     
          
          setDeleteModal({id:"",name:"",show:!deletemodal.show})
         
 } ) }

 const handleChange = (event) => {
  const name = event.target.name;
  const value = event.target.value;
  setInputs(values => ({ ...values, [name]: value }))
  // console.log(inputs)
}

  const onValueChange = (e) => {
    
    
    const name = e.target.name;
    const value = e.target.value;
    setformInputs(values => ({ ...values, [name]: value }))

  }
  const editOrder = (edit) => {
    
    axios.get(`http://localhost:8080/api/order`)
  
    data.map((ord) => {
      if (ord.id === edit.id) {

        setformInputs({ id: ord.id, name: ord.name,status:ord.status})
        setShow(true)
 }  
    })
   
  }
  const numbercount=()=>{
    
   if (validate()){
let editdata={remaining:count[0].remaining-inputs.count,total:count[0].total}
console.log(editdata)
    axios.put(`http://localhost:8080/api/count/${count[0].id}`, editdata)
    .then(function (response) {
      console.log(response);
    })
  }
  }
  const validate=()=>{
   let a=inputs.count
    let b=count[0].remaining
    let error={}
    if(a<b)
    {
return true
    }
    else{
      error["name"] = "only "+count[0].remaining+" are remaining";
    }
  setErrors(error)
  }
  const handleEdit = () => {
  //  setEditdata({ name: formInputs.name,status:formInputs.status})
 
    let editdata2 = {
      name: formInputs.name,status:formInputs.status
    }


    console.log(editdata2);
    axios.put(`http://localhost:8080/api/order/${formInputs.id}`, editdata2)
      .then(function (response) {
        console.log(response);
        setShow(!show);
        
      })
      
 }



  return (
   <div>
 
    <Table striped>
      <thead>
        <tr>
          <th>id</th>
          <th>name</th>
          <th>Adress</th>
          <th>product</th>
          <th>description</th>
          <th>Amount</th>
          <th>type</th>

          <th>phno</th>
          <th>Status</th>
          <th>edit/delete</th>
        </tr>
      </thead>
      <tbody>
      {data.map((id) => (
    
     
  
        <tr>
          <td>{id.id}</td>
          <td>{id.name}</td>
          <td>{id.adress}</td>
          <td>{id.product}</td>
          <td>{id.description}</td>
          <td>{id.amount}</td>
          <td>{id.type}</td>
          <td>{id.phno}</td>
          <td>{id.status}</td>
          <td><Button variant="warning" onClick={() => editOrder(id)}>Edit</Button>{'      '}<Button variant="danger" onClick={() => deleteScreen(id.id, id.name)} >Delete</Button> </td>
          
         
        </tr>
      
      ))}
            </tbody>

    </Table>


 <div>
   <input type="text"name='count' value={inputs.count}  onChange={handleChange}></input>
   <Button onClick={() =>numbercount()}>Order</Button>
   {errors.name?<div className="errors" style={{color:"red"}}>{errors.name}</div>:null}
 </div>


<Table>
  <thead>
  <tr>
    <th>Total</th>
    <th>remaining</th>
  </tr></thead>
  <tbody>
 
    <tr>
      <td>{count[0].total}</td>  
      <td>{count[0].remaining}</td> 
     </tr>
  
  
 
 </tbody>
</Table>
















    <Modal show={show} onHide={handleClose}>
          <Modal.Header style={{backgroundColor:"#1266F1"}}>
            <Modal.Title className='modaltitle' >Edit Order</Modal.Title>
          </Modal.Header>
          <Modal.Body style={{ overflowY: "scroll", maxHeight: "400px" }} className='modalform'>
            <Form >
              <Form.Group class="form-group required" controlId="formUser">
                <Form.Label class='control-label'>Name</Form.Label>
                <Form.Control 
                  type="text"
                  placeholder="name"
                  value={formInputs.name}
                  name="name"
                  onChange={(e) => onValueChange(e)}
                  autoFocus
                />
              </Form.Group>
              <Form.Group class="form-group required" controlId="formUser">
                <Form.Label class='control-label'>Status</Form.Label>
                <Form.Control 
                  type="text"
                  placeholder="status"
                  value={formInputs.status}
                  name="status"
                  onChange={(e) => onValueChange(e)}
                  autoFocus
                />
              </Form.Group>
             
             


            </Form>
          </Modal.Body>
          <Modal.Footer style={{backgroundColor:"#1266F1"}}>
            <Button variant="secondary" onClick={handleClose}>
              Close
            </Button>
            <Button variant="warning" onClick={handleEdit}>
              Save Changes
            </Button>
          </Modal.Footer>
        </Modal>
   


        <Modal show={deletemodal.show} onHide={() =>setDeleteModal({ id: "", name: "", show: !deletemodal.show })}>
                       
                       <Modal.Title>Confirm Delete</Modal.Title>
                                       <Modal.Body>
                                           <Row>
                                               <Col>
                                                   <p>Are you sure to delete order: <b>{deletemodal.name}?</b></p>
                                               </Col>
                                           </Row>
               
                                           <Row>
                                               <Col sm={{ offset: 7, span: 2 }}>
                                                   <Button variant="danger" onClick={() => handleDelete(deletemodal.id, deletemodal.name)}>Delete</Button>
                                               </Col>
                                               <Col sm={{ span: 3 }}>
                                                   <Button variant="secondary" onClick={() => setDeleteModal({ id: "", name: "", show: !deletemodal.show })}>Cancel</Button>
                                               </Col>
                                           </Row>
                                       </Modal.Body>
                                   </Modal>
    </div>
  );
}



export default Dashboard;
