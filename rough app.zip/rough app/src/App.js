import './App.css';
import Dashboard from './dashboard';
function App() {
  return (
   <Dashboard></Dashboard>
  );
}

export default App;
