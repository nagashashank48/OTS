module.exports = mongoose => {
    var schema = mongoose.Schema(
      {
        total:Number,
        remaining:Number
      
      },
      { timestamps: true }
    );
    schema.method("toJSON", function() {
      const { __v, _id, ...object } = this.toObject();
      object.id = _id;
      return object;
    });
    const Count = mongoose.model("count", schema);
    return Count;
  };