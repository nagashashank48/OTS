const db = require("../models");
const Count= db.count;
exports.findAll = async (req, res) => {
    await Count.find()
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving usermovie."
      });
    });
  };
  exports.update = (req, res) => {
    if (!req.body) {
      return res.status(400).send({
        message: "Data to update can not be empty!"
      });
    }
    const id = req.params.id;
    Count.findByIdAndUpdate(id, req.body, { useFindAndModify: false })
      .then(data => {
        if (!data) {
          res.status(404).send({
            message: `Cannot update order with id=${id}. Maybe screen  was not found!`
          });
        } else res.send({ message: "Order  was updated successfully." });
      })
      .catch(err => {
        res.status(500).send({
          message: "Error updating order  with id=" + id
        });
      });
  };