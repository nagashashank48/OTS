module.exports = app => {
    const count = require("../controllers/count.controller.js");
    var router = require("express").Router();
    router.get("/", count.findAll);
    router.put("/:id", count.update);
    app.use('/api/count', router);
  };