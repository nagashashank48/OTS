module.exports = app => {
    const order = require("../controllers/order.controller.js");
    var router = require("express").Router();
    router.get("/", order.findAll);
    router.put("/:id", order.update);
    router.delete("/:id",order.delete);
    app.use('/api/order', router);
  };